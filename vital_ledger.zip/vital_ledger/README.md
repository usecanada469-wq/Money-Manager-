# VITAL // LEDGER

Offline-first personal finance tracker for the Bangladeshi market — bKash, Nagad, Rocket, and bank accounts, all in one place. Dark HUD aesthetic, no login, no cloud — everything lives in a local SQLite database on your device.

## Setup

1. Install the [Flutter SDK](https://docs.flutter.dev/get-started/install) (3.3+) and Android Studio or VS Code with the Flutter extension.
2. From this folder, run:
   ```
   flutter pub get
   flutter run
   ```
3. To build a release APK: `flutter build apk --release` (output in `build/app/outputs/flutter-apk/`).

## What's fully implemented

- Dashboard with all requested summary cards, computed live from the transaction ledger (never a stored, driftable total).
- Wallets: Cash, bKash, Nagad, Rocket, Bank Account (Credit Card can be added the same way as a custom wallet) — each with balance, total received/sent, and history.
- Income / Expense entry with every field and category from the spec, plus Transfers between wallets.
- Transaction history: Today / Yesterday / This Week / This Month / Custom date filters, search by amount/category/wallet/note, and CSV/Excel/PDF export via the OS share sheet.
- Statistics: monthly income vs. expense, savings trend, category pie chart, wallet balance bars, and an Analytics panel (biggest expense, highest income, daily/monthly average, savings rate, cash flow).
- Budgets with progress bars and one-time 80%/100% local notifications per category per month.
- Savings goals with contributions and progress tracking.
- Bill reminders, including recurring bills that regenerate the next due date when marked paid.
- Recurring transactions (Daily/Weekly/Monthly/Yearly) that materialize into real ledger entries on app launch.
- PIN lock (4–6 digits) and biometric unlock via the device's own fingerprint/Face prompt.
- Local JSON backup/export/import, currency and language (English/Bengali label) settings.
- SMS parsing logic for bKash, Nagad, Rocket, and generic bank messages, with a confirm-before-save screen when parsing isn't confident.

## Two things you'll need to test on your own phone

These can't be verified from source code alone — they depend on real device permissions and hardware:

**1. SMS auto-detection** (`lib/services/sms_listener_service.dart`)
Add this to `android/app/src/main/AndroidManifest.xml`, inside `<manifest>`:
```xml
<uses-permission android:name="android.permission.RECEIVE_SMS" />
<uses-permission android:name="android.permission.READ_SMS" />
```
This is **Android-only** — iOS does not allow any app to read SMS content, by OS design, not a limitation of this code. Also note: bKash/Nagad/Rocket message wording changes over time without notice, so treat the parser as a strong starting point, not a guarantee — that's why every uncertain parse routes to a confirmation screen instead of silently saving.

To wire it in, call this once after the user grants permission (e.g. from Settings):
```dart
SmsListenerService().startListening(onParsed: (parsed) {
  if (parsed.isConfident) {
    // auto-save via AppProvider.addTransaction(...)
  } else {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => AddTransactionScreen(prefillFromSms: parsed),
    ));
  }
});
```

**2. Fingerprint / Face unlock** (`lib/services/auth_service.dart`)
Requires `local_auth` platform setup — see their [README](https://pub.dev/packages/local_auth) for the `MainActivity` change on Android (extend `FlutterFragmentActivity`) and the `NSFaceIDUsageDescription` entry in `Info.plist` on iOS. Can only be exercised on a device with enrolled biometrics.

## Architecture

```
lib/
  core/         theme, constants, formatters
  data/         SQLite schema + models (pure data, no business logic)
  domain/       repositories (typed CRUD over the database)
  providers/    app state — this is what screens actually read from
  services/     SMS parsing/listening, notifications, recurring engine,
                export, backup, biometric auth
  presentation/ screens + reusable widgets
```

Everything is offline-first: there is no network call anywhere in this codebase. The `settings` table and JSON backup format are deliberately simple so that adding real cloud sync later is a matter of also POSTing that same JSON somewhere, not a rewrite.

## Extending later

- Swap the PIN hash in `settings_provider.dart` for a real crypto hash if you ever sync settings off-device.
- `RecurringService.runDueRecurring()` runs on app launch; for guaranteed background execution even when the app is closed, add the `workmanager` package and call the same method from a periodic task.
- The `SettingsRepository` key-value table is a natural place to add more preferences without a schema migration.
