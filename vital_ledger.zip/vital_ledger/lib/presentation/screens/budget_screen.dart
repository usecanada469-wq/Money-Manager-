import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../providers/budget_provider.dart';
import '../../providers/settings_provider.dart';
import '../widgets/progress_bar_card.dart';

class BudgetScreen extends StatefulWidget {
  const BudgetScreen({super.key});

  @override
  State<BudgetScreen> createState() => _BudgetScreenState();
}

class _BudgetScreenState extends State<BudgetScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<BudgetProvider>().load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final budgetProvider = context.watch<BudgetProvider>();
    final symbol = context.watch<SettingsProvider>().currencySymbol;

    return Scaffold(
      appBar: AppBar(
        title: const Text('BUDGET'),
        actions: [
          IconButton(icon: const Icon(Icons.add_rounded), onPressed: () => _showBudgetSheet(context)),
        ],
      ),
      body: budgetProvider.budgets.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text('No budgets set for this month yet. Tap + to add one.',
                    style: TextStyle(color: AppColors.textSecondary), textAlign: TextAlign.center),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(20),
              itemCount: budgetProvider.budgets.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, i) {
                final b = budgetProvider.budgets[i];
                final spent = budgetProvider.spentOn(b.category);
                final progress = budgetProvider.progressOn(b);
                return ProgressBarCard(
                  title: b.category,
                  subtitle:
                      '${Formatters.currency(spent, symbol: symbol)} of ${Formatters.currency(b.limit, symbol: symbol)}',
                  progress: progress,
                  icon: AppConstants.categoryIcon(b.category),
                  onTap: () => _showBudgetSheet(context, existingCategory: b.category, existingLimit: b.limit),
                  trailing: IconButton(
                    icon: const Icon(Icons.close_rounded, size: 18, color: AppColors.textFaint),
                    onPressed: () => budgetProvider.deleteBudget(b.id),
                  ),
                );
              },
            ),
    );
  }

  void _showBudgetSheet(BuildContext context, {String? existingCategory, double? existingLimit}) {
    String category = existingCategory ?? AppConstants.expenseCategories.first;
    final limitController = TextEditingController(text: existingLimit?.toStringAsFixed(0) ?? '');

    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(existingCategory == null ? 'New Budget' : 'Edit Budget',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: category,
              decoration: const InputDecoration(labelText: 'Category'),
              dropdownColor: AppColors.surfaceRaised,
              isExpanded: true,
              items: AppConstants.expenseCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
              onChanged: existingCategory != null ? null : (v) => category = v!,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: limitController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Monthly limit'),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  final limit = double.tryParse(limitController.text);
                  if (limit == null || limit <= 0) return;
                  context.read<BudgetProvider>().setBudget(category, limit);
                  Navigator.pop(ctx);
                },
                child: const Text('Save Budget'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
