import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../providers/app_provider.dart';
import '../../providers/settings_provider.dart';
import '../widgets/transaction_tile.dart';

class WalletDetailScreen extends StatelessWidget {
  final String walletId;
  const WalletDetailScreen({super.key, required this.walletId});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final symbol = context.watch<SettingsProvider>().currencySymbol;
    final wallet = app.walletById(walletId);

    if (wallet == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: Text('Wallet not found')));
    }

    final summary = app.summaryFor(wallet);
    final history = app.transactionsFor(walletId);
    final color = Color(wallet.colorValue);

    return Scaffold(
      appBar: AppBar(
        title: Text(wallet.name.toUpperCase()),
        actions: [
          if (!wallet.isDefault)
            IconButton(
              icon: const Icon(Icons.delete_outline_rounded, color: AppColors.danger),
              onPressed: () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    backgroundColor: AppColors.surface,
                    title: const Text('Delete wallet?'),
                    content: const Text('This will not delete its transaction history.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                      TextButton(
                          onPressed: () => Navigator.pop(ctx, true),
                          child: const Text('Delete', style: TextStyle(color: AppColors.danger))),
                    ],
                  ),
                );
                if (confirm == true && context.mounted) {
                  await context.read<AppProvider>().deleteWallet(walletId);
                  if (context.mounted) Navigator.pop(context);
                }
              },
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(color: color.withOpacity(0.16), shape: BoxShape.circle),
                      child: Icon(AppConstants.walletIcon(wallet.iconKey), color: color),
                    ),
                    const SizedBox(width: 12),
                    const Text('Current Balance', style: TextStyle(color: AppColors.textSecondary)),
                  ],
                ),
                const SizedBox(height: 12),
                Text(Formatters.currency(summary.balance, symbol: symbol), style: AppTheme.amountLarge),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _statBox('Total Received', Formatters.currency(summary.totalReceived, symbol: symbol),
                    AppColors.signal),
              ),
              const SizedBox(width: 12),
              Expanded(
                child:
                    _statBox('Total Sent', Formatters.currency(summary.totalSent, symbol: symbol), AppColors.warn),
              ),
            ],
          ),
          const SizedBox(height: 24),
          const Text('Transaction History', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
          const SizedBox(height: 8),
          if (history.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 24),
              child: Text('No transactions for this wallet yet.', style: TextStyle(color: AppColors.textSecondary)),
            )
          else
            ...history.map((tx) => TransactionTile(tx: tx, wallet: wallet, currencySymbol: symbol)),
        ],
      ),
    );
  }

  Widget _statBox(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
          const SizedBox(height: 6),
          Text(value, style: AppTheme.amountSmall.copyWith(color: color, fontSize: 16)),
        ],
      ),
    );
  }
}
