import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../providers/settings_provider.dart';
import '../../services/auth_service.dart';

class PinLockScreen extends StatefulWidget {
  final VoidCallback onUnlocked;
  const PinLockScreen({super.key, required this.onUnlocked});

  @override
  State<PinLockScreen> createState() => _PinLockScreenState();
}

class _PinLockScreenState extends State<PinLockScreen> {
  String _entered = '';
  String? _error;

  @override
  void initState() {
    super.initState();
    final settings = context.read<SettingsProvider>();
    if (settings.biometricEnabled) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _tryBiometric());
    }
  }

  Future<void> _tryBiometric() async {
    final ok = await AuthService().authenticate();
    if (ok && mounted) widget.onUnlocked();
  }

  void _onDigit(String d) {
    if (_entered.length >= 6) return;
    setState(() {
      _entered += d;
      _error = null;
    });
    if (_entered.length >= 4) _tryVerify();
  }

  void _tryVerify() {
    final settings = context.read<SettingsProvider>();
    if (settings.verifyPin(_entered)) {
      widget.onUnlocked();
    } else if (_entered.length == 6) {
      setState(() {
        _error = 'Incorrect PIN';
        _entered = '';
      });
    }
  }

  void _backspace() => setState(() => _entered = _entered.isEmpty ? '' : _entered.substring(0, _entered.length - 1));

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            const Spacer(),
            const Icon(Icons.lock_rounded, color: AppColors.signal, size: 36),
            const SizedBox(height: 16),
            const Text('VITAL // LEDGER', style: TextStyle(fontWeight: FontWeight.w700, letterSpacing: 1.2)),
            const SizedBox(height: 6),
            Text(_error ?? 'Enter your PIN',
                style: TextStyle(color: _error != null ? AppColors.danger : AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 28),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(6, (i) {
                final filled = i < _entered.length;
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 6),
                  width: 14,
                  height: 14,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: filled ? AppColors.signal : AppColors.surfaceRaised,
                    border: Border.all(color: AppColors.border),
                  ),
                );
              }),
            ),
            const Spacer(),
            _numberPad(settings),
            const Spacer(),
          ],
        ),
      ),
    );
  }

  Widget _numberPad(SettingsProvider settings) {
    final rows = [
      ['1', '2', '3'],
      ['4', '5', '6'],
      ['7', '8', '9'],
      [settings.biometricEnabled ? 'bio' : '', '0', 'back'],
    ];
    return Column(
      children: rows
          .map((row) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: row.map((key) {
                    Widget child;
                    VoidCallback? onTap;
                    if (key == 'back') {
                      child = const Icon(Icons.backspace_outlined, color: AppColors.textSecondary, size: 20);
                      onTap = _backspace;
                    } else if (key == 'bio') {
                      child = const Icon(Icons.fingerprint_rounded, color: AppColors.signal, size: 24);
                      onTap = _tryBiometric;
                    } else if (key.isEmpty) {
                      child = const SizedBox();
                    } else {
                      child = Text(key, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w600));
                      onTap = () => _onDigit(key);
                    }
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      child: InkWell(
                        onTap: onTap,
                        customBorder: const CircleBorder(),
                        child: Container(width: 64, height: 64, alignment: Alignment.center, child: child),
                      ),
                    );
                  }).toList(),
                ),
              ))
          .toList(),
    );
  }
}
