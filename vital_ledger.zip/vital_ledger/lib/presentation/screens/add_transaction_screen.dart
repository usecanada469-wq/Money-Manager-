import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/transaction_model.dart';
import '../../providers/app_provider.dart';
import '../../providers/budget_provider.dart';
import '../../providers/settings_provider.dart';
import '../../services/sms_parser_service.dart';

/// Handles Income, Expense, and Transfer entry in one screen via a
/// segmented control, plus an optional pre-fill path used when a parsed
/// SMS transaction needs user confirmation before it's saved.
class AddTransactionScreen extends StatefulWidget {
  final ParsedSmsTransaction? prefillFromSms;
  const AddTransactionScreen({super.key, this.prefillFromSms});

  @override
  State<AddTransactionScreen> createState() => _AddTransactionScreenState();
}

class _AddTransactionScreenState extends State<AddTransactionScreen> {
  TxType _type = TxType.expense;
  final _amountController = TextEditingController();
  final _sourceController = TextEditingController();
  final _notesController = TextEditingController();
  String? _walletId;
  String? _toWalletId;
  String _category = AppConstants.expenseCategories.first;
  DateTime _date = DateTime.now();

  @override
  void initState() {
    super.initState();
    final sms = widget.prefillFromSms;
    if (sms != null) {
      _type = sms.isIncome ? TxType.income : TxType.expense;
      _category = sms.isIncome ? 'Other' : 'Other';
      _amountController.text = sms.amount?.toStringAsFixed(2) ?? '';
      _notesController.text = 'Auto-detected from ${sms.provider} SMS: ${sms.action}';
      _date = sms.date ?? DateTime.now();
      _sourceController.text = sms.sender ?? sms.receiver ?? '';
    }
  }

  @override
  void dispose() {
    _amountController.dispose();
    _sourceController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _walletId ??= context.read<AppProvider>().wallets.isNotEmpty
        ? context.read<AppProvider>().wallets.first.id
        : null;
  }

  List<String> get _categories => _type == TxType.income ? AppConstants.incomeCategories : AppConstants.expenseCategories;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final symbol = context.watch<SettingsProvider>().currencySymbol;

    return Scaffold(
      appBar: AppBar(title: const Text('ADD TRANSACTION')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (widget.prefillFromSms != null) _smsBanner(widget.prefillFromSms!),
            _typeSelector(),
            const SizedBox(height: 20),
            TextField(
              controller: _amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              style: AppTheme.amountMedium,
              decoration: InputDecoration(labelText: 'Amount ($symbol)'),
            ),
            const SizedBox(height: 14),
            if (_type == TxType.income) ...[
              TextField(
                controller: _sourceController,
                decoration: const InputDecoration(labelText: 'Source (e.g. employer, client)'),
              ),
              const SizedBox(height: 14),
            ],
            _dropdown('Category', _category, _categories, (v) => setState(() => _category = v!)),
            const SizedBox(height: 14),
            _walletDropdown(
              label: _type == TxType.transfer ? 'From Wallet' : 'Wallet',
              app: app,
              value: _walletId,
              onChanged: (v) => setState(() => _walletId = v),
            ),
            if (_type == TxType.transfer) ...[
              const SizedBox(height: 14),
              _walletDropdown(
                label: 'To Wallet',
                app: app,
                value: _toWalletId,
                onChanged: (v) => setState(() => _toWalletId = v),
              ),
            ],
            const SizedBox(height: 14),
            _dateField(),
            const SizedBox(height: 14),
            TextField(
              controller: _notesController,
              maxLines: 2,
              decoration: const InputDecoration(labelText: 'Notes (optional)'),
            ),
            const SizedBox(height: 24),
            ElevatedButton(onPressed: _save, child: const Text('Save Transaction')),
          ],
        ),
      ),
    );
  }

  Widget _smsBanner(ParsedSmsTransaction sms) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.info.withOpacity(0.1),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.info.withOpacity(0.4)),
      ),
      child: Row(
        children: [
          const Icon(Icons.sms_rounded, color: AppColors.info, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              'Detected from ${sms.provider} SMS. ${sms.isConfident ? 'Please confirm the details below.' : "Couldn't fully parse this message — please fill in or correct any details."}',
              style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
            ),
          ),
        ],
      ),
    );
  }

  Widget _typeSelector() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(color: AppColors.surfaceRaised, borderRadius: BorderRadius.circular(14)),
      child: Row(
        children: TxType.values.map((t) {
          final selected = _type == t;
          final label = t == TxType.income ? 'Income' : (t == TxType.expense ? 'Expense' : 'Transfer');
          final color = t == TxType.income
              ? AppColors.signal
              : (t == TxType.expense ? AppColors.warn : AppColors.info);
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() {
                _type = t;
                _category = _categories.first;
              }),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: selected ? color.withOpacity(0.18) : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                ),
                alignment: Alignment.center,
                child: Text(label,
                    style: TextStyle(
                        color: selected ? color : AppColors.textFaint,
                        fontWeight: FontWeight.w600,
                        fontSize: 13)),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _dropdown(String label, String value, List<String> items, ValueChanged<String?> onChanged) {
    return DropdownButtonFormField<String>(
      value: value,
      decoration: InputDecoration(labelText: label),
      dropdownColor: AppColors.surfaceRaised,
      isExpanded: true,
      items: items.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
      onChanged: onChanged,
    );
  }

  Widget _walletDropdown({
    required String label,
    required AppProvider app,
    required String? value,
    required ValueChanged<String?> onChanged,
  }) {
    return DropdownButtonFormField<String>(
      value: value,
      decoration: InputDecoration(labelText: label),
      dropdownColor: AppColors.surfaceRaised,
      isExpanded: true,
      items: app.wallets
          .map((w) => DropdownMenuItem(value: w.id, child: Text(w.name)))
          .toList(),
      onChanged: onChanged,
    );
  }

  Widget _dateField() {
    return InkWell(
      onTap: () async {
        final picked = await showDatePicker(
          context: context,
          initialDate: _date,
          firstDate: DateTime(2020),
          lastDate: DateTime(2100),
        );
        if (picked != null) setState(() => _date = picked);
      },
      child: InputDecorator(
        decoration: const InputDecoration(labelText: 'Date'),
        child: Text('${_date.day}/${_date.month}/${_date.year}'),
      ),
    );
  }

  Future<void> _save() async {
    final amount = double.tryParse(_amountController.text);
    if (amount == null || amount <= 0 || _walletId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid amount and wallet.')),
      );
      return;
    }
    if (_type == TxType.transfer && (_toWalletId == null || _toWalletId == _walletId)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please choose a different destination wallet.')),
      );
      return;
    }

    final app = context.read<AppProvider>();
    await app.addTransaction(
      type: _type,
      amount: amount,
      walletId: _walletId!,
      toWalletId: _type == TxType.transfer ? _toWalletId : null,
      category: _type == TxType.transfer ? 'Transfer' : _category,
      date: _date,
      notes: _notesController.text.trim(),
      source: _sourceController.text.trim(),
      isFromSms: widget.prefillFromSms != null,
    );

    if (_type == TxType.expense && mounted) {
      final budgetProvider = context.read<BudgetProvider>();
      await budgetProvider.load();
      await budgetProvider.checkThresholds();
    }

    if (mounted) Navigator.pop(context);
  }
}
