import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/settings_provider.dart';
import '../../services/auth_service.dart';
import '../../services/backup_service.dart';
import '../../services/notification_service.dart';
import 'recurring_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('SETTINGS')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _section('General'),
          _tile(
            icon: Icons.attach_money_rounded,
            title: 'Currency',
            subtitle: '${settings.currencyCode} (${settings.currencySymbol})',
            onTap: () => _showCurrencyPicker(context),
          ),
          _tile(
            icon: Icons.language_rounded,
            title: 'Language',
            subtitle: settings.languageCode == 'bn' ? 'বাংলা (Bengali)' : 'English',
            onTap: () => _showLanguagePicker(context),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            secondary: const Icon(Icons.dark_mode_rounded, color: AppColors.textSecondary),
            title: const Text('Dark Theme'),
            subtitle: const Text('Light theme coming soon', style: TextStyle(fontSize: 11)),
            value: settings.themeMode == ThemeMode.dark,
            activeColor: AppColors.signal,
            onChanged: (v) => settings.setThemeMode(v ? ThemeMode.dark : ThemeMode.light),
          ),
          _tile(
            icon: Icons.repeat_rounded,
            title: 'Recurring Transactions',
            subtitle: 'Salary, rent, subscriptions, bills',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const RecurringScreen())),
          ),
          const SizedBox(height: 20),
          _section('Security'),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            secondary: const Icon(Icons.lock_rounded, color: AppColors.textSecondary),
            title: const Text('PIN Lock'),
            value: settings.pinLockEnabled,
            activeColor: AppColors.signal,
            onChanged: (v) => v ? _showSetPinDialog(context) : settings.disablePinLock(),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            secondary: const Icon(Icons.fingerprint_rounded, color: AppColors.textSecondary),
            title: const Text('Fingerprint / Face Unlock'),
            subtitle: const Text('Uses your device\'s biometric hardware', style: TextStyle(fontSize: 11)),
            value: settings.biometricEnabled,
            activeColor: AppColors.signal,
            onChanged: (v) async {
              if (v) {
                final available = await AuthService().isBiometricAvailable();
                if (!available) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Biometric hardware not available or not enrolled on this device.')),
                    );
                  }
                  return;
                }
              }
              settings.setBiometricEnabled(v);
            },
          ),
          const SizedBox(height: 20),
          _section('Notifications'),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Daily expense reminder'),
            value: settings.dailyReminderEnabled,
            activeColor: AppColors.signal,
            onChanged: (v) {
              settings.setNotificationToggle('dailyReminderEnabled', v);
              if (v) NotificationService().scheduleDailyReminder();
            },
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Weekly summary'),
            value: settings.weeklySummaryEnabled,
            activeColor: AppColors.signal,
            onChanged: (v) {
              settings.setNotificationToggle('weeklySummaryEnabled', v);
              if (v) NotificationService().scheduleWeeklySummary();
            },
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Monthly summary'),
            value: settings.monthlySummaryEnabled,
            activeColor: AppColors.signal,
            onChanged: (v) {
              settings.setNotificationToggle('monthlySummaryEnabled', v);
              if (v) NotificationService().scheduleMonthlySummary();
            },
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Budget alerts (80% / 100%)'),
            value: settings.budgetAlertsEnabled,
            activeColor: AppColors.signal,
            onChanged: (v) => settings.setNotificationToggle('budgetAlertsEnabled', v),
          ),
          const SizedBox(height: 20),
          _section('Backup'),
          _tile(
            icon: Icons.upload_rounded,
            title: 'Export Backup',
            subtitle: 'Save all your data as a local JSON file',
            onTap: () async {
              await BackupService().exportAndShareBackup();
            },
          ),
          _tile(
            icon: Icons.download_rounded,
            title: 'Import Backup',
            subtitle: 'Restore from a previously exported file',
            onTap: () async {
              final ok = await BackupService().importBackup();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(ok ? 'Backup restored. Restart the app to see all changes.' : 'Import cancelled or failed.')),
                );
              }
            },
          ),
          _tile(
            icon: Icons.delete_forever_rounded,
            title: 'Wipe Local Data',
            subtitle: 'Permanently delete everything on this device',
            danger: true,
            onTap: () => _confirmWipe(context),
          ),
          const SizedBox(height: 24),
          const Center(
            child: Text('VITAL // LEDGER — v1.0.0\nAll data stored locally on this device.',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: AppColors.textFaint)),
          ),
        ],
      ),
    );
  }

  Widget _section(String title) => Padding(
        padding: const EdgeInsets.only(bottom: 8, top: 4),
        child: Text(title.toUpperCase(),
            style: const TextStyle(fontSize: 12, color: AppColors.textFaint, letterSpacing: 1, fontWeight: FontWeight.w600)),
      );

  Widget _tile({
    required IconData icon,
    required String title,
    String? subtitle,
    required VoidCallback onTap,
    bool danger = false,
  }) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(icon, color: danger ? AppColors.danger : AppColors.textSecondary),
      title: Text(title, style: TextStyle(color: danger ? AppColors.danger : AppColors.textPrimary)),
      subtitle: subtitle != null ? Text(subtitle, style: const TextStyle(fontSize: 11)) : null,
      trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.textFaint),
      onTap: onTap,
    );
  }

  void _showCurrencyPicker(BuildContext context) {
    final settings = context.read<SettingsProvider>();
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: AppConstants.currencySymbols.entries
              .map((e) => ListTile(
                    title: Text('${e.key} (${e.value})'),
                    onTap: () {
                      settings.setCurrency(e.key, e.value);
                      Navigator.pop(ctx);
                    },
                  ))
              .toList(),
        ),
      ),
    );
  }

  void _showLanguagePicker(BuildContext context) {
    final settings = context.read<SettingsProvider>();
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(title: const Text('English'), onTap: () { settings.setLanguage('en'); Navigator.pop(ctx); }),
            ListTile(title: const Text('বাংলা (Bengali)'), onTap: () { settings.setLanguage('bn'); Navigator.pop(ctx); }),
          ],
        ),
      ),
    );
  }

  void _showSetPinDialog(BuildContext context) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Set a 4-6 digit PIN'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          obscureText: true,
          maxLength: 6,
          decoration: const InputDecoration(counterText: ''),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              if (controller.text.length >= 4) {
                context.read<SettingsProvider>().setPin(controller.text);
                Navigator.pop(ctx);
              }
            },
            child: const Text('Save', style: TextStyle(color: AppColors.signal)),
          ),
        ],
      ),
    );
  }

  void _confirmWipe(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Wipe all local data?'),
        content: const Text('This permanently deletes every wallet, transaction, budget, goal, and bill on this device. This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () async {
              await BackupService().wipeLocalData();
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('Wipe Everything', style: TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
  }
}
