import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../providers/app_provider.dart';
import '../../providers/settings_provider.dart';
import '../widgets/summary_card.dart';
import '../widgets/transaction_tile.dart';
import 'settings_screen.dart';
import 'transactions_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final settings = context.watch<SettingsProvider>();
    final symbol = settings.currencySymbol;

    if (app.isLoading) {
      return const Center(child: CircularProgressIndicator(color: AppColors.signal));
    }

    final remainingBudget = app.incomeThisMonth - app.expenseThisMonth;

    return RefreshIndicator(
      color: AppColors.signal,
      backgroundColor: AppColors.surface,
      onRefresh: app.reload,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 100),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('VITAL // LEDGER',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16, letterSpacing: 1.2)),
              Row(
                children: [
                  Text(Formatters.monthYear(DateTime.now()),
                      style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                  IconButton(
                    icon: const Icon(Icons.settings_outlined, size: 20, color: AppColors.textSecondary),
                    onPressed: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Hero: total money
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: const LinearGradient(
                colors: [AppColors.surfaceRaised, AppColors.surface],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('TOTAL BALANCE',
                    style: TextStyle(color: AppColors.textSecondary, fontSize: 12, letterSpacing: 1)),
                const SizedBox(height: 8),
                Text(Formatters.currency(app.totalMoney, symbol: symbol), style: AppTheme.amountLarge),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Wallet balances quick row
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.5,
            children: [
              SummaryCard(
                label: 'Cash in Hand',
                value: Formatters.currencyCompact(app.balanceForWalletNamed('Cash'), symbol: symbol),
                icon: Icons.payments_rounded,
                accent: const Color(0xFF6EE7B7),
              ),
              SummaryCard(
                label: 'bKash Balance',
                value: Formatters.currencyCompact(app.balanceForWalletNamed('bKash'), symbol: symbol),
                icon: Icons.smartphone_rounded,
                accent: const Color(0xFFE2136E),
              ),
              SummaryCard(
                label: 'Nagad Balance',
                value: Formatters.currencyCompact(app.balanceForWalletNamed('Nagad'), symbol: symbol),
                icon: Icons.smartphone_rounded,
                accent: const Color(0xFFF7941D),
              ),
              SummaryCard(
                label: 'Bank Balance',
                value: Formatters.currencyCompact(app.balanceForWalletNamed('Bank Account'), symbol: symbol),
                icon: Icons.account_balance_rounded,
                accent: const Color(0xFF60A5FA),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Income / Expense / Savings / Remaining budget
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.5,
            children: [
              SummaryCard(
                label: 'Income This Month',
                value: Formatters.currencyCompact(app.incomeThisMonth, symbol: symbol),
                icon: Icons.arrow_downward_rounded,
                accent: AppColors.signal,
              ),
              SummaryCard(
                label: 'Expense This Month',
                value: Formatters.currencyCompact(app.expenseThisMonth, symbol: symbol),
                icon: Icons.arrow_upward_rounded,
                accent: AppColors.warn,
              ),
              SummaryCard(
                label: 'Savings',
                value: Formatters.currencyCompact(app.savingsThisMonth, symbol: symbol),
                icon: Icons.savings_rounded,
                accent: AppColors.violet,
              ),
              SummaryCard(
                label: 'Remaining Budget',
                value: Formatters.currencyCompact(remainingBudget, symbol: symbol),
                icon: Icons.speed_rounded,
                accent: AppColors.info,
              ),
            ],
          ),
          const SizedBox(height: 24),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Recent Transactions',
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
              TextButton(
                onPressed: () => Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => const TransactionsScreen())),
                child: const Text('See all', style: TextStyle(color: AppColors.signal)),
              ),
            ],
          ),
          if (app.recentTransactions.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 24),
              child: Text('No transactions yet. Tap + to add your first one.',
                  style: TextStyle(color: AppColors.textSecondary)),
            )
          else
            ...app.recentTransactions.map(
              (tx) => TransactionTile(tx: tx, wallet: app.walletById(tx.walletId), currencySymbol: symbol),
            ),
        ],
      ),
    );
  }
}
