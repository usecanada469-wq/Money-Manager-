import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import 'add_transaction_screen.dart';
import 'bills_screen.dart';
import 'budget_screen.dart';
import 'dashboard_screen.dart';
import 'goals_screen.dart';
import 'statistics_screen.dart';
import 'transactions_screen.dart';
import 'wallets_screen.dart';

/// Bottom nav has the 5 highest-frequency destinations; Budget, Goals,
/// and Bills live one tap away from Statistics via a segmented row so
/// the nav bar itself doesn't get overcrowded on small screens.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  final _screens = const [
    DashboardScreen(),
    WalletsScreen(),
    _PlanningHub(),
    TransactionsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: _screens[_index]),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.signal,
        foregroundColor: Colors.black,
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const AddTransactionScreen()),
        ),
        child: const Icon(Icons.add_rounded, size: 28),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        color: AppColors.surface,
        shape: const CircularNotchedRectangle(),
        notchMargin: 8,
        child: SizedBox(
          height: 60,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _navItem(Icons.dashboard_rounded, 'Home', 0),
              _navItem(Icons.account_balance_wallet_rounded, 'Wallets', 1),
              const SizedBox(width: 40),
              _navItem(Icons.pie_chart_rounded, 'Plan', 2),
              _navItem(Icons.receipt_long_rounded, 'History', 3),
            ],
          ),
        ),
      ),
    );
  }

  Widget _navItem(IconData icon, String label, int idx) {
    final selected = _index == idx;
    final color = selected ? AppColors.signal : AppColors.textFaint;
    return InkWell(
      onTap: () => setState(() => _index = idx),
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(color: color, fontSize: 10)),
          ],
        ),
      ),
    );
  }
}

/// "Plan" tab: quick links into Statistics, Budget, Goals, and Bills so
/// all four planning surfaces stay reachable without cluttering the
/// bottom nav bar.
class _PlanningHub extends StatelessWidget {
  const _PlanningHub();

  @override
  Widget build(BuildContext context) {
    final items = [
      ('Statistics', Icons.bar_chart_rounded, AppColors.info, const StatisticsScreen()),
      ('Budget', Icons.pie_chart_rounded, AppColors.warn, const BudgetScreen()),
      ('Savings Goals', Icons.flag_rounded, AppColors.violet, const GoalsScreen()),
      ('Bills Reminder', Icons.event_note_rounded, AppColors.signal, const BillsScreen()),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('PLAN')),
      body: ListView.separated(
        padding: const EdgeInsets.all(20),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, i) {
          final (label, icon, color, screen) = items[i];
          return Material(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(18),
            child: InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen)),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: AppColors.border),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(color: color.withOpacity(0.15), shape: BoxShape.circle),
                      child: Icon(icon, color: color),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                        child: Text(label, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600))),
                    const Icon(Icons.chevron_right_rounded, color: AppColors.textFaint),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
