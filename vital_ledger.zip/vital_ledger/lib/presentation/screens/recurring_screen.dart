import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/planning_models.dart';
import '../../providers/app_provider.dart';
import '../../providers/settings_provider.dart';
import '../../services/recurring_service.dart';

class RecurringScreen extends StatefulWidget {
  const RecurringScreen({super.key});

  @override
  State<RecurringScreen> createState() => _RecurringScreenState();
}

class _RecurringScreenState extends State<RecurringScreen> {
  final _service = RecurringService();
  List<RecurringModel> _templates = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await _service.getAll();
    if (mounted) setState(() => _templates = list);
  }

  @override
  Widget build(BuildContext context) {
    final symbol = context.watch<SettingsProvider>().currencySymbol;

    return Scaffold(
      appBar: AppBar(
        title: const Text('RECURRING'),
        actions: [IconButton(icon: const Icon(Icons.add_rounded), onPressed: _showCreateSheet)],
      ),
      body: _templates.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text('No recurring transactions set — e.g. Salary, Rent, or Subscriptions.',
                    style: TextStyle(color: AppColors.textSecondary), textAlign: TextAlign.center),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(20),
              itemCount: _templates.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final r = _templates[i];
                return Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(r.category, style: const TextStyle(fontWeight: FontWeight.w600)),
                            const SizedBox(height: 2),
                            Text('${r.frequency} · next ${Formatters.date(r.nextRunDate)}',
                                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                          ],
                        ),
                      ),
                      Text(
                        '${r.type == 'income' ? '+' : '-'}${Formatters.currency(r.amount, symbol: symbol)}',
                        style: AppTheme.amountSmall.copyWith(
                          color: r.type == 'income' ? AppColors.signal : AppColors.warn,
                        ),
                      ),
                      Switch(
                        value: r.isActive,
                        activeColor: AppColors.signal,
                        onChanged: (v) async {
                          await _service.setActive(r, v);
                          _load();
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }

  void _showCreateSheet() {
    String type = 'expense';
    final amountController = TextEditingController();
    String category = AppConstants.expenseCategories.first;
    String? walletId = context.read<AppProvider>().wallets.isNotEmpty
        ? context.read<AppProvider>().wallets.first.id
        : null;
    String frequency = 'Monthly';
    DateTime startDate = DateTime.now();

    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) {
          final app = context.watch<AppProvider>();
          final categories = type == 'income' ? AppConstants.incomeCategories : AppConstants.expenseCategories;
          return Padding(
            padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('New Recurring Transaction', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ChoiceChip(
                          label: const Text('Income'),
                          selected: type == 'income',
                          selectedColor: AppColors.signal,
                          onSelected: (_) => setSheetState(() {
                            type = 'income';
                            category = AppConstants.incomeCategories.first;
                          }),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ChoiceChip(
                          label: const Text('Expense'),
                          selected: type == 'expense',
                          selectedColor: AppColors.warn,
                          onSelected: (_) => setSheetState(() {
                            type = 'expense';
                            category = AppConstants.expenseCategories.first;
                          }),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: amountController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Amount'),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: category,
                    decoration: const InputDecoration(labelText: 'Category'),
                    dropdownColor: AppColors.surfaceRaised,
                    isExpanded: true,
                    items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                    onChanged: (v) => setSheetState(() => category = v!),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: walletId,
                    decoration: const InputDecoration(labelText: 'Wallet'),
                    dropdownColor: AppColors.surfaceRaised,
                    isExpanded: true,
                    items: app.wallets.map((w) => DropdownMenuItem(value: w.id, child: Text(w.name))).toList(),
                    onChanged: (v) => setSheetState(() => walletId = v),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: frequency,
                    decoration: const InputDecoration(labelText: 'Frequency'),
                    dropdownColor: AppColors.surfaceRaised,
                    items: AppConstants.recurrenceFrequencies.map((f) => DropdownMenuItem(value: f, child: Text(f))).toList(),
                    onChanged: (v) => setSheetState(() => frequency = v!),
                  ),
                  const SizedBox(height: 12),
                  InkWell(
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: ctx,
                        initialDate: startDate,
                        firstDate: DateTime.now().subtract(const Duration(days: 1)),
                        lastDate: DateTime(2100),
                      );
                      if (picked != null) setSheetState(() => startDate = picked);
                    },
                    child: InputDecorator(
                      decoration: const InputDecoration(labelText: 'First run date'),
                      child: Text(Formatters.date(startDate)),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () async {
                        final amount = double.tryParse(amountController.text);
                        if (amount == null || amount <= 0 || walletId == null) return;
                        await _service.createTemplate(RecurringModel(
                          id: const Uuid().v4(),
                          type: type,
                          amount: amount,
                          category: category,
                          walletId: walletId!,
                          frequency: frequency,
                          nextRunDate: startDate,
                        ));
                        if (mounted) Navigator.pop(ctx);
                        _load();
                      },
                      child: const Text('Save Recurring Transaction'),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
