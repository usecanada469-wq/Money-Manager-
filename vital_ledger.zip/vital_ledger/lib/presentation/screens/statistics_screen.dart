import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../providers/app_provider.dart';
import '../../providers/settings_provider.dart';

class StatisticsScreen extends StatelessWidget {
  const StatisticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final symbol = context.watch<SettingsProvider>().currencySymbol;
    final months = app.monthlyTotals(6);
    final categoryBreakdown = app.expenseByCategoryThisMonth();

    return Scaffold(
      appBar: AppBar(title: const Text('STATISTICS')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _sectionCard(
            title: 'Monthly Income vs Expense',
            child: SizedBox(
              height: 200,
              child: BarChart(
                BarChartData(
                  gridData: const FlGridData(show: false),
                  borderData: FlBorderData(show: false),
                  titlesData: FlTitlesData(
                    leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          final i = value.toInt();
                          if (i < 0 || i >= months.length) return const SizedBox();
                          return Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Text(
                              Formatters.monthYear(months[i].month).split(' ')[0].substring(0, 3),
                              style: const TextStyle(fontSize: 10, color: AppColors.textSecondary),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  barGroups: [
                    for (int i = 0; i < months.length; i++)
                      BarChartGroupData(x: i, barRods: [
                        BarChartRodData(toY: months[i].income, color: AppColors.signal, width: 8, borderRadius: BorderRadius.circular(4)),
                        BarChartRodData(toY: months[i].expense, color: AppColors.warn, width: 8, borderRadius: BorderRadius.circular(4)),
                      ]),
                  ],
                ),
              ),
            ),
            legend: const [('Income', AppColors.signal), ('Expense', AppColors.warn)],
          ),
          const SizedBox(height: 16),
          _sectionCard(
            title: 'Savings Trend',
            child: SizedBox(
              height: 180,
              child: LineChart(
                LineChartData(
                  gridData: const FlGridData(show: false),
                  borderData: FlBorderData(show: false),
                  titlesData: const FlTitlesData(show: false),
                  lineBarsData: [
                    LineChartBarData(
                      spots: [
                        for (int i = 0; i < months.length; i++)
                          FlSpot(i.toDouble(), months[i].income - months[i].expense),
                      ],
                      isCurved: true,
                      color: AppColors.violet,
                      barWidth: 3,
                      dotData: const FlDotData(show: true),
                      belowBarData: BarAreaData(show: true, color: AppColors.violet.withOpacity(0.12)),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          _sectionCard(
            title: 'Category-wise Expenses (This Month)',
            child: categoryBreakdown.isEmpty
                ? const Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: Text('No expenses recorded this month.', style: TextStyle(color: AppColors.textSecondary)),
                  )
                : Column(
                    children: [
                      SizedBox(
                        height: 180,
                        child: PieChart(
                          PieChartData(
                            sectionsSpace: 2,
                            centerSpaceRadius: 42,
                            sections: _pieSections(categoryBreakdown),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      ...categoryBreakdown.entries.take(6).map((e) => Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              children: [
                                Container(width: 10, height: 10, decoration: BoxDecoration(color: _colorFor(e.key), shape: BoxShape.circle)),
                                const SizedBox(width: 8),
                                Expanded(child: Text(e.key, style: const TextStyle(fontSize: 13))),
                                Text(Formatters.currency(e.value, symbol: symbol),
                                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                              ],
                            ),
                          )),
                    ],
                  ),
          ),
          const SizedBox(height: 16),
          _sectionCard(
            title: 'Wallet Balances',
            child: Column(
              children: app.wallets.map((w) {
                final s = app.summaryFor(w);
                final total = app.totalMoney == 0 ? 1 : app.totalMoney;
                final ratio = (s.balance / total).clamp(0, 1).toDouble();
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    children: [
                      SizedBox(width: 80, child: Text(w.name, style: const TextStyle(fontSize: 12))),
                      Expanded(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: LinearProgressIndicator(
                            value: ratio,
                            minHeight: 8,
                            backgroundColor: AppColors.surfaceRaised,
                            valueColor: AlwaysStoppedAnimation(Color(w.colorValue)),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(Formatters.currencyCompact(s.balance, symbol: symbol), style: const TextStyle(fontSize: 12)),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 16),
          _analyticsSection(app, symbol),
        ],
      ),
    );
  }

  Widget _analyticsSection(AppProvider app, String symbol) {
    return _sectionCard(
      title: 'Analytics',
      child: Column(
        children: [
          _analyticsRow('Biggest Expense', app.biggestExpense == null ? '—' : '${app.biggestExpense!.category}: ${Formatters.currency(app.biggestExpense!.amount, symbol: symbol)}'),
          _analyticsRow('Highest Income', app.highestIncome == null ? '—' : '${app.highestIncome!.category}: ${Formatters.currency(app.highestIncome!.amount, symbol: symbol)}'),
          _analyticsRow('Daily Average Spending', Formatters.currency(app.dailyAverageSpending, symbol: symbol)),
          _analyticsRow('Monthly Average Spending', Formatters.currency(app.monthlyAverageSpending, symbol: symbol)),
          _analyticsRow('Savings Rate', '${app.savingsRate.toStringAsFixed(1)}%'),
          _analyticsRow('Net Cash Flow', Formatters.currency(app.netCashFlow, symbol: symbol)),
        ],
      ),
    );
  }

  Widget _analyticsRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
          Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  List<PieChartSectionData> _pieSections(Map<String, double> data) {
    final total = data.values.fold(0.0, (s, v) => s + v);
    return data.entries.map((e) {
      final pct = total == 0 ? 0 : (e.value / total * 100);
      return PieChartSectionData(
        value: e.value,
        color: _colorFor(e.key),
        title: '${pct.toStringAsFixed(0)}%',
        radius: 54,
        titleStyle: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: Colors.black),
      );
    }).toList();
  }

  Color _colorFor(String category) {
    final palette = [
      AppColors.signal,
      AppColors.warn,
      AppColors.violet,
      AppColors.info,
      const Color(0xFFF7941D),
      const Color(0xFFE2136E),
      const Color(0xFF6EE7B7),
    ];
    return palette[category.hashCode.abs() % palette.length];
  }

  Widget _sectionCard({required String title, required Widget child, List<(String, Color)>? legend}) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
              if (legend != null)
                Row(
                  children: legend
                      .map((l) => Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Row(
                              children: [
                                Container(width: 8, height: 8, decoration: BoxDecoration(color: l.$2, shape: BoxShape.circle)),
                                const SizedBox(width: 4),
                                Text(l.$1, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                              ],
                            ),
                          ))
                      .toList(),
                ),
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}
