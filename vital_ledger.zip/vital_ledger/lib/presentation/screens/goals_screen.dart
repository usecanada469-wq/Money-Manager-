import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../providers/goal_provider.dart';
import '../../providers/settings_provider.dart';
import '../widgets/progress_bar_card.dart';

class GoalsScreen extends StatefulWidget {
  const GoalsScreen({super.key});

  @override
  State<GoalsScreen> createState() => _GoalsScreenState();
}

class _GoalsScreenState extends State<GoalsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<GoalProvider>().load());
  }

  @override
  Widget build(BuildContext context) {
    final goalProvider = context.watch<GoalProvider>();
    final symbol = context.watch<SettingsProvider>().currencySymbol;

    return Scaffold(
      appBar: AppBar(
        title: const Text('SAVINGS GOALS'),
        actions: [IconButton(icon: const Icon(Icons.add_rounded), onPressed: () => _showCreateGoalSheet(context))],
      ),
      body: goalProvider.goals.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text('No goals yet — try "New Phone" or "Emergency Fund".',
                    style: TextStyle(color: AppColors.textSecondary), textAlign: TextAlign.center),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(20),
              itemCount: goalProvider.goals.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, i) {
                final g = goalProvider.goals[i];
                return ProgressBarCard(
                  title: g.name,
                  subtitle:
                      '${Formatters.currency(g.saved, symbol: symbol)} of ${Formatters.currency(g.target, symbol: symbol)} · ${(g.progress * 100).toStringAsFixed(0)}%',
                  progress: g.progress,
                  icon: Icons.flag_rounded,
                  color: AppColors.violet,
                  onTap: () => _showContributeSheet(context, g.id, g.name),
                  trailing: IconButton(
                    icon: const Icon(Icons.close_rounded, size: 18, color: AppColors.textFaint),
                    onPressed: () => goalProvider.deleteGoal(g.id),
                  ),
                );
              },
            ),
    );
  }

  void _showCreateGoalSheet(BuildContext context) {
    final nameController = TextEditingController();
    final targetController = TextEditingController();

    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('New Savings Goal', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            TextField(controller: nameController, decoration: const InputDecoration(labelText: 'Goal name (e.g. Japan Trip)')),
            const SizedBox(height: 12),
            TextField(
              controller: targetController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Target amount'),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  final target = double.tryParse(targetController.text);
                  if (nameController.text.trim().isEmpty || target == null || target <= 0) return;
                  context.read<GoalProvider>().createGoal(name: nameController.text.trim(), target: target);
                  Navigator.pop(ctx);
                },
                child: const Text('Create Goal'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showContributeSheet(BuildContext context, String goalId, String goalName) {
    final amountController = TextEditingController();
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Add to "$goalName"', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              autofocus: true,
              decoration: const InputDecoration(labelText: 'Contribution amount'),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  final amount = double.tryParse(amountController.text);
                  if (amount == null || amount <= 0) return;
                  final goal = context.read<GoalProvider>().goals.firstWhere((g) => g.id == goalId);
                  context.read<GoalProvider>().addContribution(goal, amount);
                  Navigator.pop(ctx);
                },
                child: const Text('Add Contribution'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
