import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../providers/bill_provider.dart';
import '../../providers/settings_provider.dart';

class BillsScreen extends StatefulWidget {
  const BillsScreen({super.key});

  @override
  State<BillsScreen> createState() => _BillsScreenState();
}

class _BillsScreenState extends State<BillsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<BillProvider>().load());
  }

  @override
  Widget build(BuildContext context) {
    final billProvider = context.watch<BillProvider>();
    final symbol = context.watch<SettingsProvider>().currencySymbol;
    final upcoming = billProvider.upcoming;

    return Scaffold(
      appBar: AppBar(
        title: const Text('BILLS REMINDER'),
        actions: [IconButton(icon: const Icon(Icons.add_rounded), onPressed: () => _showCreateBillSheet(context))],
      ),
      body: upcoming.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text('No upcoming bills. Tap + to add one.',
                    style: TextStyle(color: AppColors.textSecondary), textAlign: TextAlign.center),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(20),
              itemCount: upcoming.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final b = upcoming[i];
                final daysLeft = b.dueDate.difference(DateTime.now()).inDays;
                final urgent = daysLeft <= 2;
                return Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: urgent ? AppColors.warn.withOpacity(0.5) : AppColors.border),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: (urgent ? AppColors.warn : AppColors.signal).withOpacity(0.14),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(AppConstants.categoryIcon(b.category),
                            color: urgent ? AppColors.warn : AppColors.signal, size: 18),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(b.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                            const SizedBox(height: 2),
                            Text(
                              'Due ${Formatters.date(b.dueDate)} · ${daysLeft < 0 ? 'Overdue' : '$daysLeft days left'}',
                              style: TextStyle(fontSize: 12, color: urgent ? AppColors.warn : AppColors.textSecondary),
                            ),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(Formatters.currency(b.amount, symbol: symbol), style: AppTheme.amountSmall),
                          TextButton(
                            onPressed: () => context.read<BillProvider>().markPaid(b),
                            child: const Text('Mark Paid', style: TextStyle(fontSize: 11)),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }

  void _showCreateBillSheet(BuildContext context) {
    final nameController = TextEditingController();
    final amountController = TextEditingController();
    String category = AppConstants.billCategories.first;
    DateTime dueDate = DateTime.now().add(const Duration(days: 7));
    bool recurring = false;
    String frequency = 'Monthly';

    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => Padding(
          padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('New Bill Reminder', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                const SizedBox(height: 16),
                TextField(controller: nameController, decoration: const InputDecoration(labelText: 'Bill name')),
                const SizedBox(height: 12),
                TextField(
                  controller: amountController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Amount'),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: category,
                  decoration: const InputDecoration(labelText: 'Category'),
                  dropdownColor: AppColors.surfaceRaised,
                  isExpanded: true,
                  items: AppConstants.billCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                  onChanged: (v) => setSheetState(() => category = v!),
                ),
                const SizedBox(height: 12),
                InkWell(
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: ctx,
                      initialDate: dueDate,
                      firstDate: DateTime.now(),
                      lastDate: DateTime(2100),
                    );
                    if (picked != null) setSheetState(() => dueDate = picked);
                  },
                  child: InputDecorator(
                    decoration: const InputDecoration(labelText: 'Due date'),
                    child: Text(Formatters.date(dueDate)),
                  ),
                ),
                const SizedBox(height: 12),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: recurring,
                  activeColor: AppColors.signal,
                  title: const Text('Repeats'),
                  onChanged: (v) => setSheetState(() => recurring = v),
                ),
                if (recurring)
                  DropdownButtonFormField<String>(
                    value: frequency,
                    decoration: const InputDecoration(labelText: 'Frequency'),
                    dropdownColor: AppColors.surfaceRaised,
                    items: AppConstants.recurrenceFrequencies
                        .map((f) => DropdownMenuItem(value: f, child: Text(f)))
                        .toList(),
                    onChanged: (v) => setSheetState(() => frequency = v!),
                  ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      final amount = double.tryParse(amountController.text);
                      if (nameController.text.trim().isEmpty || amount == null || amount <= 0) return;
                      context.read<BillProvider>().createBill(
                            name: nameController.text.trim(),
                            amount: amount,
                            dueDate: dueDate,
                            category: category,
                            isRecurring: recurring,
                            recurrenceFrequency: recurring ? frequency : '',
                          );
                      Navigator.pop(ctx);
                    },
                    child: const Text('Save Bill'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
