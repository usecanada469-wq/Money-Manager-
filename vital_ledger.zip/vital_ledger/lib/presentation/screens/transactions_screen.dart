import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';
import '../../data/models/transaction_model.dart';
import '../../providers/app_provider.dart';
import '../../providers/settings_provider.dart';
import '../../services/export_service.dart';
import '../widgets/transaction_tile.dart';

enum _DateFilter { today, yesterday, thisWeek, thisMonth, custom, all }

class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({super.key});

  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  _DateFilter _filter = _DateFilter.all;
  DateTime? _customStart;
  DateTime? _customEnd;
  final _searchController = TextEditingController();

  (DateTime?, DateTime?) get _range {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    switch (_filter) {
      case _DateFilter.today:
        return (today, today.add(const Duration(days: 1)).subtract(const Duration(milliseconds: 1)));
      case _DateFilter.yesterday:
        final y = today.subtract(const Duration(days: 1));
        return (y, y.add(const Duration(days: 1)).subtract(const Duration(milliseconds: 1)));
      case _DateFilter.thisWeek:
        final start = today.subtract(Duration(days: today.weekday % 7));
        return (start, now);
      case _DateFilter.thisMonth:
        return (DateTime(now.year, now.month, 1), now);
      case _DateFilter.custom:
        return (_customStart, _customEnd);
      case _DateFilter.all:
        return (null, null);
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final symbol = context.watch<SettingsProvider>().currencySymbol;
    final (start, end) = _range;
    final txRepoFiltered = _applyFilters(app, start, end);

    return Scaffold(
      appBar: AppBar(
        title: const Text('HISTORY'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.ios_share_rounded),
            color: AppColors.surfaceRaised,
            onSelected: (v) async {
              final exporter = ExportService();
              if (v == 'csv') await exporter.exportCsv(txRepoFiltered, app.wallets);
              if (v == 'excel') await exporter.exportExcel(txRepoFiltered, app.wallets);
              if (v == 'pdf') await exporter.exportPdf(txRepoFiltered, app.wallets);
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'csv', child: Text('Export as CSV')),
              PopupMenuItem(value: 'excel', child: Text('Export as Excel')),
              PopupMenuItem(value: 'pdf', child: Text('Export as PDF')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
            child: TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                hintText: 'Search amount, category, wallet, or note',
                prefixIcon: Icon(Icons.search_rounded, size: 20),
              ),
              onChanged: (_) => setState(() {}),
            ),
          ),
          SizedBox(
            height: 40,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              children: [
                _chip('Today', _DateFilter.today),
                _chip('Yesterday', _DateFilter.yesterday),
                _chip('This Week', _DateFilter.thisWeek),
                _chip('This Month', _DateFilter.thisMonth),
                _chip('All', _DateFilter.all),
                _customChip(),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: txRepoFiltered.isEmpty
                ? const Center(
                    child: Text('No transactions match this filter.',
                        style: TextStyle(color: AppColors.textSecondary)))
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    itemCount: txRepoFiltered.length,
                    itemBuilder: (context, i) {
                      final tx = txRepoFiltered[i];
                      return TransactionTile(
                        tx: tx,
                        wallet: app.walletById(tx.walletId),
                        currencySymbol: symbol,
                        onTap: () => _showDeleteSheet(context, tx.id),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  List<TransactionModel> _applyFilters(AppProvider app, DateTime? start, DateTime? end) {
    return app.transactions.where((t) {
      if (start != null && t.date.isBefore(start)) return false;
      if (end != null && t.date.isAfter(end)) return false;
      if (_searchController.text.trim().isNotEmpty) {
        final q = _searchController.text.toLowerCase();
        final hay = '${t.amount} ${t.category} ${t.notes} ${t.source}'.toLowerCase();
        if (!hay.contains(q)) return false;
      }
      return true;
    }).toList()
      ..sort((a, b) => b.date.compareTo(a.date));
  }

  Widget _chip(String label, _DateFilter filter) {
    final selected = _filter == filter;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label, style: const TextStyle(fontSize: 12)),
        selected: selected,
        selectedColor: AppColors.signal,
        backgroundColor: AppColors.surfaceRaised,
        labelStyle: TextStyle(color: selected ? Colors.black : AppColors.textSecondary),
        onSelected: (_) => setState(() => _filter = filter),
      ),
    );
  }

  Widget _customChip() {
    final selected = _filter == _DateFilter.custom;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: const Text('Custom', style: TextStyle(fontSize: 12)),
        selected: selected,
        selectedColor: AppColors.signal,
        backgroundColor: AppColors.surfaceRaised,
        labelStyle: TextStyle(color: selected ? Colors.black : AppColors.textSecondary),
        onSelected: (_) async {
          final range = await showDateRangePicker(
            context: context,
            firstDate: DateTime(2020),
            lastDate: DateTime(2100),
          );
          if (range != null) {
            setState(() {
              _filter = _DateFilter.custom;
              _customStart = range.start;
              _customEnd = range.end;
            });
          }
        },
      ),
    );
  }

  void _showDeleteSheet(BuildContext context, String txId) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.delete_outline_rounded, color: AppColors.danger),
                title: const Text('Delete transaction'),
                onTap: () {
                  context.read<AppProvider>().deleteTransaction(txId);
                  Navigator.pop(ctx);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
