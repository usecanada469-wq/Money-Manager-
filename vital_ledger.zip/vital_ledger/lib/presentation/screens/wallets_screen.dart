import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/wallet_model.dart';
import '../../providers/app_provider.dart';
import '../../providers/settings_provider.dart';
import '../widgets/wallet_card.dart';
import 'wallet_detail_screen.dart';

class WalletsScreen extends StatelessWidget {
  const WalletsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final symbol = context.watch<SettingsProvider>().currencySymbol;

    return Scaffold(
      appBar: AppBar(
        title: const Text('WALLETS'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_rounded),
            onPressed: () => _showCreateWalletSheet(context),
          ),
        ],
      ),
      body: app.wallets.isEmpty
          ? const Center(child: Text('No wallets yet', style: TextStyle(color: AppColors.textSecondary)))
          : GridView.builder(
              padding: const EdgeInsets.all(20),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 14,
                mainAxisSpacing: 14,
                childAspectRatio: 0.95,
              ),
              itemCount: app.wallets.length,
              itemBuilder: (context, i) {
                final summary = app.summaryFor(app.wallets[i]);
                return WalletCard(
                  summary: summary,
                  currencySymbol: symbol,
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => WalletDetailScreen(walletId: summary.wallet.id)),
                  ),
                );
              },
            ),
    );
  }

  void _showCreateWalletSheet(BuildContext context) {
    final nameController = TextEditingController();
    final balanceController = TextEditingController(text: '0');
    String iconKey = 'cash';
    int color = 0xFF6EE7B7;

    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 20,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('New Wallet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
              const SizedBox(height: 16),
              TextField(controller: nameController, decoration: const InputDecoration(labelText: 'Wallet name')),
              const SizedBox(height: 12),
              TextField(
                controller: balanceController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Opening balance'),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 10,
                children: AppConstants.defaultWallets.map((w) {
                  final key = w['icon'] as String;
                  final selected = key == iconKey;
                  return ChoiceChip(
                    label: Icon(AppConstants.walletIcon(key), size: 18, color: selected ? Colors.black : null),
                    selected: selected,
                    selectedColor: AppColors.signal,
                    backgroundColor: AppColors.surfaceRaised,
                    onSelected: (_) {
                      iconKey = key;
                      color = w['color'] as int;
                      (ctx as Element).markNeedsBuild();
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    if (nameController.text.trim().isEmpty) return;
                    context.read<AppProvider>().createWallet(WalletModel(
                          id: const Uuid().v4(),
                          name: nameController.text.trim(),
                          iconKey: iconKey,
                          colorValue: color,
                          openingBalance: double.tryParse(balanceController.text) ?? 0,
                          createdAt: DateTime.now(),
                        ));
                    Navigator.pop(ctx);
                  },
                  child: const Text('Create Wallet'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
