import 'package:flutter/material.dart';

import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/wallet_model.dart';

class WalletCard extends StatelessWidget {
  final WalletSummary summary;
  final String currencySymbol;
  final VoidCallback onTap;

  const WalletCard({
    super.key,
    required this.summary,
    required this.onTap,
    this.currencySymbol = '৳',
  });

  @override
  Widget build(BuildContext context) {
    final color = Color(summary.wallet.colorValue);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          width: 168,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: color.withOpacity(0.16), shape: BoxShape.circle),
                child: Icon(AppConstants.walletIcon(summary.wallet.iconKey), color: color, size: 18),
              ),
              const SizedBox(height: 14),
              Text(
                Formatters.currencyCompact(summary.balance, symbol: currencySymbol),
                style: AppTheme.amountMedium,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 2),
              Text(summary.wallet.name,
                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            ],
          ),
        ),
      ),
    );
  }
}
