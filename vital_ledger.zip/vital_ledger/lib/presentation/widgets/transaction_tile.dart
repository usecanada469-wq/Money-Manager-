import 'package:flutter/material.dart';

import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/transaction_model.dart';
import '../../data/models/wallet_model.dart';

class TransactionTile extends StatelessWidget {
  final TransactionModel tx;
  final WalletModel? wallet;
  final String currencySymbol;
  final VoidCallback? onTap;

  const TransactionTile({
    super.key,
    required this.tx,
    required this.wallet,
    this.currencySymbol = '৳',
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isIncome = tx.type == TxType.income;
    final isTransfer = tx.type == TxType.transfer;
    final color = isTransfer ? AppColors.info : (isIncome ? AppColors.signal : AppColors.warn);
    final sign = isTransfer ? '' : (isIncome ? '+' : '-');

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(color: color.withOpacity(0.14), shape: BoxShape.circle),
                child: Icon(
                  isTransfer ? Icons.swap_horiz_rounded : AppConstants.categoryIcon(tx.category),
                  color: color,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      tx.category,
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${wallet?.name ?? 'Unknown wallet'} · ${Formatters.relativeDay(tx.date)}'
                      '${tx.isFromSms ? ' · SMS' : ''}',
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Text(
                '$sign${Formatters.currency(tx.amount, symbol: currencySymbol)}',
                style: AppTheme.amountSmall.copyWith(color: color),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
