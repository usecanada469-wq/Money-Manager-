import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/theme/app_theme.dart';
import 'presentation/screens/home_shell.dart';
import 'presentation/screens/pin_lock_screen.dart';
import 'providers/app_provider.dart';
import 'providers/bill_provider.dart';
import 'providers/budget_provider.dart';
import 'providers/goal_provider.dart';
import 'providers/settings_provider.dart';
import 'services/notification_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const VitalLedgerApp());
}

class VitalLedgerApp extends StatelessWidget {
  const VitalLedgerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()..init()),
        ChangeNotifierProvider(create: (_) => SettingsProvider()..load()),
        ChangeNotifierProxyProvider<AppProvider, BudgetProvider>(
          create: (ctx) => BudgetProvider(ctx.read<AppProvider>())..load(),
          update: (ctx, app, previous) => previous ?? BudgetProvider(app)..load(),
        ),
        ChangeNotifierProvider(create: (_) => GoalProvider()..load()),
        ChangeNotifierProvider(create: (_) => BillProvider()..load()),
      ],
      child: MaterialApp(
        title: 'VITAL // LEDGER',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark(),
        darkTheme: AppTheme.dark(),
        themeMode: ThemeMode.dark,
        home: const _AppGate(),
      ),
    );
  }
}

/// Decides whether to show the PIN lock screen before letting the user
/// into the app. Waits for both AppProvider (DB + recurring engine) and
/// SettingsProvider (PIN/biometric flags) to finish loading first.
class _AppGate extends StatefulWidget {
  const _AppGate();

  @override
  State<_AppGate> createState() => _AppGateState();
}

class _AppGateState extends State<_AppGate> {
  bool _unlocked = false;

  @override
  void initState() {
    super.initState();
    NotificationService().init();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final settings = context.watch<SettingsProvider>();

    if (app.isLoading) {
      return const Scaffold(
        backgroundColor: AppColors.bg,
        body: Center(child: CircularProgressIndicator(color: AppColors.signal)),
      );
    }

    if (settings.pinLockEnabled && !_unlocked) {
      return PinLockScreen(onUnlocked: () => setState(() => _unlocked = true));
    }

    return const HomeShell();
  }
}
