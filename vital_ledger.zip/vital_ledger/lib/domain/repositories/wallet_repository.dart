import '../../data/db/database_helper.dart';
import '../../data/models/wallet_model.dart';

class WalletRepository {
  final _db = DatabaseHelper.instance;

  Future<List<WalletModel>> getAll() async {
    final rows = await _db.queryAll('wallets', orderBy: 'createdAt ASC');
    return rows.map(WalletModel.fromMap).toList();
  }

  Future<void> create(WalletModel wallet) => _db.insert('wallets', wallet.toMap());

  Future<void> update(WalletModel wallet) => _db.update('wallets', wallet.toMap(), 'id', wallet.id);

  Future<void> delete(String id) => _db.delete('wallets', 'id', id);

  /// Seeds the six default wallets on first launch only.
  Future<void> seedDefaultsIfEmpty() async {
    final existing = await getAll();
    if (existing.isNotEmpty) return;
    final now = DateTime.now();
    const defaults = [
      {'name': 'Cash', 'icon': 'cash', 'color': 0xFF6EE7B7},
      {'name': 'bKash', 'icon': 'bkash', 'color': 0xFFE2136E},
      {'name': 'Nagad', 'icon': 'nagad', 'color': 0xFFF7941D},
      {'name': 'Rocket', 'icon': 'rocket', 'color': 0xFF8B5CF6},
      {'name': 'Bank Account', 'icon': 'bank', 'color': 0xFF60A5FA},
    ];
    for (var i = 0; i < defaults.length; i++) {
      final d = defaults[i];
      await create(WalletModel(
        id: 'wallet_${d['icon']}',
        name: d['name'] as String,
        iconKey: d['icon'] as String,
        colorValue: d['color'] as int,
        isDefault: true,
        createdAt: now.add(Duration(milliseconds: i)),
      ));
    }
  }
}
