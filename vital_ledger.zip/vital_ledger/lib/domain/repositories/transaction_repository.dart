import '../../data/db/database_helper.dart';
import '../../data/models/transaction_model.dart';

class TransactionRepository {
  final _db = DatabaseHelper.instance;

  Future<List<TransactionModel>> getAll() async {
    final rows = await _db.queryAll('transactions', orderBy: 'date DESC');
    return rows.map(TransactionModel.fromMap).toList();
  }

  Future<void> create(TransactionModel tx) => _db.insert('transactions', tx.toMap());

  Future<void> update(TransactionModel tx) => _db.update('transactions', tx.toMap(), 'id', tx.id);

  Future<void> delete(String id) => _db.delete('transactions', 'id', id);

  /// In-memory filter/search — the full ledger for a personal finance app
  /// realistically stays small enough (thousands of rows) that this is
  /// simpler and just as fast as building dynamic SQL, and it keeps every
  /// filter combination (date range + search text) trivial to reason about.
  List<TransactionModel> applyFilters(
    List<TransactionModel> all, {
    DateTime? start,
    DateTime? end,
    String? searchQuery,
    String? walletId,
    String? category,
    TxType? type,
  }) {
    return all.where((tx) {
      if (start != null && tx.date.isBefore(start)) return false;
      if (end != null && tx.date.isAfter(end)) return false;
      if (walletId != null && tx.walletId != walletId && tx.toWalletId != walletId) return false;
      if (category != null && tx.category != category) return false;
      if (type != null && tx.type != type) return false;
      if (searchQuery != null && searchQuery.trim().isNotEmpty) {
        final q = searchQuery.toLowerCase();
        final haystack = [
          tx.amount.toString(),
          tx.category.toLowerCase(),
          tx.notes.toLowerCase(),
          tx.source.toLowerCase(),
        ].join(' ');
        if (!haystack.contains(q)) return false;
      }
      return true;
    }).toList();
  }
}
