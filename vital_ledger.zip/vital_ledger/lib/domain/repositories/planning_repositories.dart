import '../../data/db/database_helper.dart';
import '../../data/models/planning_models.dart';

class BudgetRepository {
  final _db = DatabaseHelper.instance;

  Future<List<BudgetModel>> getForMonth(String monthKey) async {
    final db = await _db.database;
    final rows = await db.query('budgets', where: 'monthKey = ?', whereArgs: [monthKey]);
    return rows.map(BudgetModel.fromMap).toList();
  }

  Future<void> upsert(BudgetModel budget) => _db.insert('budgets', budget.toMap());

  Future<void> delete(String id) => _db.delete('budgets', 'id', id);
}

class GoalRepository {
  final _db = DatabaseHelper.instance;

  Future<List<GoalModel>> getAll() async {
    final rows = await _db.queryAll('goals', orderBy: 'createdAt DESC');
    return rows.map(GoalModel.fromMap).toList();
  }

  Future<void> create(GoalModel goal) => _db.insert('goals', goal.toMap());
  Future<void> update(GoalModel goal) => _db.update('goals', goal.toMap(), 'id', goal.id);
  Future<void> delete(String id) => _db.delete('goals', 'id', id);
}

class BillRepository {
  final _db = DatabaseHelper.instance;

  Future<List<BillModel>> getAll() async {
    final rows = await _db.queryAll('bills', orderBy: 'dueDate ASC');
    return rows.map(BillModel.fromMap).toList();
  }

  Future<void> create(BillModel bill) => _db.insert('bills', bill.toMap());
  Future<void> update(BillModel bill) => _db.update('bills', bill.toMap(), 'id', bill.id);
  Future<void> delete(String id) => _db.delete('bills', 'id', id);
}

class RecurringRepository {
  final _db = DatabaseHelper.instance;

  Future<List<RecurringModel>> getAll() async {
    final rows = await _db.queryAll('recurring');
    return rows.map(RecurringModel.fromMap).toList();
  }

  Future<void> create(RecurringModel r) => _db.insert('recurring', r.toMap());
  Future<void> update(RecurringModel r) => _db.update('recurring', r.toMap(), 'id', r.id);
  Future<void> delete(String id) => _db.delete('recurring', 'id', id);
}

class SettingsRepository {
  final _db = DatabaseHelper.instance;

  Future<String?> get(String key) async {
    final db = await _db.database;
    final rows = await db.query('settings', where: 'key = ?', whereArgs: [key]);
    if (rows.isEmpty) return null;
    return rows.first['value'] as String;
  }

  Future<void> set(String key, String value) => _db.insert('settings', {'key': key, 'value': value});
}
