import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

/// Single source of truth for the on-device SQLite database.
/// Everything is local — nothing here ever calls the network.
/// A `schemaVersion` bump + entry in `_onUpgrade` is how this app
/// will grow its schema later without breaking existing installs.
class DatabaseHelper {
  DatabaseHelper._internal();
  static final DatabaseHelper instance = DatabaseHelper._internal();

  static const int schemaVersion = 1;
  Database? _db;

  Future<Database> get database async {
    _db ??= await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'vital_ledger.db');
    return openDatabase(
      path,
      version: schemaVersion,
      onCreate: _onCreate,
      onConfigure: (db) async => db.execute('PRAGMA foreign_keys = ON'),
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE wallets (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        iconKey TEXT NOT NULL,
        colorValue INTEGER NOT NULL,
        openingBalance REAL NOT NULL DEFAULT 0,
        isDefault INTEGER NOT NULL DEFAULT 0,
        createdAt TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE transactions (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        amount REAL NOT NULL,
        walletId TEXT NOT NULL,
        toWalletId TEXT,
        category TEXT NOT NULL,
        date TEXT NOT NULL,
        notes TEXT DEFAULT '',
        source TEXT DEFAULT '',
        isFromSms INTEGER NOT NULL DEFAULT 0,
        isRecurringInstance INTEGER NOT NULL DEFAULT 0,
        createdAt TEXT NOT NULL,
        FOREIGN KEY (walletId) REFERENCES wallets (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE budgets (
        id TEXT PRIMARY KEY,
        category TEXT NOT NULL,
        "limit" REAL NOT NULL,
        monthKey TEXT NOT NULL,
        notified80 INTEGER NOT NULL DEFAULT 0,
        notified100 INTEGER NOT NULL DEFAULT 0,
        UNIQUE(category, monthKey)
      )
    ''');

    await db.execute('''
      CREATE TABLE goals (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        target REAL NOT NULL,
        saved REAL NOT NULL DEFAULT 0,
        iconKey TEXT DEFAULT 'goal',
        deadline TEXT,
        createdAt TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE bills (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        amount REAL NOT NULL,
        dueDate TEXT NOT NULL,
        category TEXT NOT NULL,
        isPaid INTEGER NOT NULL DEFAULT 0,
        isRecurring INTEGER NOT NULL DEFAULT 0,
        recurrenceFrequency TEXT DEFAULT ''
      )
    ''');

    await db.execute('''
      CREATE TABLE recurring (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        amount REAL NOT NULL,
        category TEXT NOT NULL,
        walletId TEXT NOT NULL,
        frequency TEXT NOT NULL,
        nextRunDate TEXT NOT NULL,
        notes TEXT DEFAULT '',
        isActive INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    ''');

    await db.execute('CREATE INDEX idx_tx_date ON transactions(date)');
    await db.execute('CREATE INDEX idx_tx_wallet ON transactions(walletId)');
    await db.execute('CREATE INDEX idx_tx_category ON transactions(category)');
  }

  // -----------------------------------------------------------------
  // Generic helpers used by the repositories
  // -----------------------------------------------------------------
  Future<int> insert(String table, Map<String, dynamic> row) async {
    final db = await database;
    return db.insert(table, row, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<int> update(String table, Map<String, dynamic> row, String idColumn, String id) async {
    final db = await database;
    return db.update(table, row, where: '$idColumn = ?', whereArgs: [id]);
  }

  Future<int> delete(String table, String idColumn, String id) async {
    final db = await database;
    return db.delete(table, where: '$idColumn = ?', whereArgs: [id]);
  }

  Future<List<Map<String, dynamic>>> queryAll(String table, {String? orderBy}) async {
    final db = await database;
    return db.query(table, orderBy: orderBy);
  }

  Future<void> wipeAllData() async {
    final db = await database;
    final batch = db.batch();
    for (final t in ['transactions', 'wallets', 'budgets', 'goals', 'bills', 'recurring']) {
      batch.delete(t);
    }
    await batch.commit(noResult: true);
  }
}
