class WalletModel {
  final String id;
  final String name;
  final String iconKey;
  final int colorValue;
  final double openingBalance;
  final bool isDefault;
  final DateTime createdAt;

  WalletModel({
    required this.id,
    required this.name,
    required this.iconKey,
    required this.colorValue,
    this.openingBalance = 0,
    this.isDefault = false,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'iconKey': iconKey,
        'colorValue': colorValue,
        'openingBalance': openingBalance,
        'isDefault': isDefault ? 1 : 0,
        'createdAt': createdAt.toIso8601String(),
      };

  factory WalletModel.fromMap(Map<String, dynamic> map) => WalletModel(
        id: map['id'] as String,
        name: map['name'] as String,
        iconKey: map['iconKey'] as String,
        colorValue: map['colorValue'] as int,
        openingBalance: (map['openingBalance'] as num).toDouble(),
        isDefault: (map['isDefault'] as int) == 1,
        createdAt: DateTime.parse(map['createdAt'] as String),
      );
}

/// Computed, in-memory view of a wallet with its running totals.
/// This is derived from transactions, never stored directly, so it
/// can never drift out of sync with the transaction ledger.
class WalletSummary {
  final WalletModel wallet;
  final double totalReceived;
  final double totalSent;

  WalletSummary({
    required this.wallet,
    required this.totalReceived,
    required this.totalSent,
  });

  double get balance => wallet.openingBalance + totalReceived - totalSent;
}
