/// Budget: one row per (category, month). monthKey format: 'yyyy-MM'.
class BudgetModel {
  final String id;
  final String category;
  final double limit;
  final String monthKey;
  final bool notified80;
  final bool notified100;

  BudgetModel({
    required this.id,
    required this.category,
    required this.limit,
    required this.monthKey,
    this.notified80 = false,
    this.notified100 = false,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'category': category,
        'limit': limit,
        'monthKey': monthKey,
        'notified80': notified80 ? 1 : 0,
        'notified100': notified100 ? 1 : 0,
      };

  factory BudgetModel.fromMap(Map<String, dynamic> map) => BudgetModel(
        id: map['id'] as String,
        category: map['category'] as String,
        limit: (map['limit'] as num).toDouble(),
        monthKey: map['monthKey'] as String,
        notified80: (map['notified80'] as int? ?? 0) == 1,
        notified100: (map['notified100'] as int? ?? 0) == 1,
      );

  BudgetModel copyWith({bool? notified80, bool? notified100}) => BudgetModel(
        id: id,
        category: category,
        limit: limit,
        monthKey: monthKey,
        notified80: notified80 ?? this.notified80,
        notified100: notified100 ?? this.notified100,
      );
}

/// Savings goal, e.g. "Japan Trip" — target amount, saved-so-far amount.
class GoalModel {
  final String id;
  final String name;
  final double target;
  final double saved;
  final String iconKey;
  final DateTime? deadline;
  final DateTime createdAt;

  GoalModel({
    required this.id,
    required this.name,
    required this.target,
    this.saved = 0,
    this.iconKey = 'goal',
    this.deadline,
    required this.createdAt,
  });

  double get progress => target <= 0 ? 0 : (saved / target).clamp(0, 1);

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'target': target,
        'saved': saved,
        'iconKey': iconKey,
        'deadline': deadline?.toIso8601String(),
        'createdAt': createdAt.toIso8601String(),
      };

  factory GoalModel.fromMap(Map<String, dynamic> map) => GoalModel(
        id: map['id'] as String,
        name: map['name'] as String,
        target: (map['target'] as num).toDouble(),
        saved: (map['saved'] as num).toDouble(),
        iconKey: map['iconKey'] as String? ?? 'goal',
        deadline: map['deadline'] != null ? DateTime.parse(map['deadline'] as String) : null,
        createdAt: DateTime.parse(map['createdAt'] as String),
      );

  GoalModel copyWith({double? saved}) => GoalModel(
        id: id,
        name: name,
        target: target,
        saved: saved ?? this.saved,
        iconKey: iconKey,
        deadline: deadline,
        createdAt: createdAt,
      );
}

/// Bill reminder, e.g. "Internet Bill" due on the 5th of every month.
class BillModel {
  final String id;
  final String name;
  final double amount;
  final DateTime dueDate;
  final String category;
  final bool isPaid;
  final bool isRecurring;
  final String recurrenceFrequency; // 'Monthly', 'Yearly', etc. Empty if not recurring.

  BillModel({
    required this.id,
    required this.name,
    required this.amount,
    required this.dueDate,
    required this.category,
    this.isPaid = false,
    this.isRecurring = false,
    this.recurrenceFrequency = '',
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'amount': amount,
        'dueDate': dueDate.toIso8601String(),
        'category': category,
        'isPaid': isPaid ? 1 : 0,
        'isRecurring': isRecurring ? 1 : 0,
        'recurrenceFrequency': recurrenceFrequency,
      };

  factory BillModel.fromMap(Map<String, dynamic> map) => BillModel(
        id: map['id'] as String,
        name: map['name'] as String,
        amount: (map['amount'] as num).toDouble(),
        dueDate: DateTime.parse(map['dueDate'] as String),
        category: map['category'] as String,
        isPaid: (map['isPaid'] as int? ?? 0) == 1,
        isRecurring: (map['isRecurring'] as int? ?? 0) == 1,
        recurrenceFrequency: map['recurrenceFrequency'] as String? ?? '',
      );

  BillModel copyWith({bool? isPaid, DateTime? dueDate}) => BillModel(
        id: id,
        name: name,
        amount: amount,
        dueDate: dueDate ?? this.dueDate,
        category: category,
        isPaid: isPaid ?? this.isPaid,
        isRecurring: isRecurring,
        recurrenceFrequency: recurrenceFrequency,
      );
}

/// Recurring transaction template (Salary, Rent, Subscriptions, Internet Bill).
/// A background check (see RecurringService) materializes these into real
/// TransactionModel rows in the ledger when `nextRunDate` has passed.
class RecurringModel {
  final String id;
  final String type; // 'income' or 'expense'
  final double amount;
  final String category;
  final String walletId;
  final String frequency; // Daily / Weekly / Monthly / Yearly
  final DateTime nextRunDate;
  final String notes;
  final bool isActive;

  RecurringModel({
    required this.id,
    required this.type,
    required this.amount,
    required this.category,
    required this.walletId,
    required this.frequency,
    required this.nextRunDate,
    this.notes = '',
    this.isActive = true,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'type': type,
        'amount': amount,
        'category': category,
        'walletId': walletId,
        'frequency': frequency,
        'nextRunDate': nextRunDate.toIso8601String(),
        'notes': notes,
        'isActive': isActive ? 1 : 0,
      };

  factory RecurringModel.fromMap(Map<String, dynamic> map) => RecurringModel(
        id: map['id'] as String,
        type: map['type'] as String,
        amount: (map['amount'] as num).toDouble(),
        category: map['category'] as String,
        walletId: map['walletId'] as String,
        frequency: map['frequency'] as String,
        nextRunDate: DateTime.parse(map['nextRunDate'] as String),
        notes: map['notes'] as String? ?? '',
        isActive: (map['isActive'] as int? ?? 1) == 1,
      );

  RecurringModel copyWith({DateTime? nextRunDate, bool? isActive}) => RecurringModel(
        id: id,
        type: type,
        amount: amount,
        category: category,
        walletId: walletId,
        frequency: frequency,
        nextRunDate: nextRunDate ?? this.nextRunDate,
        notes: notes,
        isActive: isActive ?? this.isActive,
      );

  static DateTime advance(DateTime from, String frequency) {
    switch (frequency) {
      case 'Daily':
        return from.add(const Duration(days: 1));
      case 'Weekly':
        return from.add(const Duration(days: 7));
      case 'Yearly':
        return DateTime(from.year + 1, from.month, from.day);
      case 'Monthly':
      default:
        final month = from.month == 12 ? 1 : from.month + 1;
        final year = from.month == 12 ? from.year + 1 : from.year;
        final lastDay = DateTime(year, month + 1, 0).day;
        final day = from.day > lastDay ? lastDay : from.day;
        return DateTime(year, month, day);
    }
  }
}
