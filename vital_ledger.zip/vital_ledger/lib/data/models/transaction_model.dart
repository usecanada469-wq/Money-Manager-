enum TxType { income, expense, transfer }

TxType txTypeFromString(String s) => TxType.values.firstWhere((e) => e.name == s);

class TransactionModel {
  final String id;
  final TxType type;
  final double amount;
  final String walletId;
  // For transfers: the destination wallet. Null otherwise.
  final String? toWalletId;
  final String category;
  final DateTime date;
  final String notes;
  // For income: the source label (e.g. employer name, client name).
  final String source;
  final bool isFromSms;
  final bool isRecurringInstance;
  final DateTime createdAt;

  TransactionModel({
    required this.id,
    required this.type,
    required this.amount,
    required this.walletId,
    this.toWalletId,
    required this.category,
    required this.date,
    this.notes = '',
    this.source = '',
    this.isFromSms = false,
    this.isRecurringInstance = false,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'type': type.name,
        'amount': amount,
        'walletId': walletId,
        'toWalletId': toWalletId,
        'category': category,
        'date': date.toIso8601String(),
        'notes': notes,
        'source': source,
        'isFromSms': isFromSms ? 1 : 0,
        'isRecurringInstance': isRecurringInstance ? 1 : 0,
        'createdAt': createdAt.toIso8601String(),
      };

  factory TransactionModel.fromMap(Map<String, dynamic> map) => TransactionModel(
        id: map['id'] as String,
        type: txTypeFromString(map['type'] as String),
        amount: (map['amount'] as num).toDouble(),
        walletId: map['walletId'] as String,
        toWalletId: map['toWalletId'] as String?,
        category: map['category'] as String,
        date: DateTime.parse(map['date'] as String),
        notes: map['notes'] as String? ?? '',
        source: map['source'] as String? ?? '',
        isFromSms: (map['isFromSms'] as int? ?? 0) == 1,
        isRecurringInstance: (map['isRecurringInstance'] as int? ?? 0) == 1,
        createdAt: DateTime.parse(map['createdAt'] as String),
      );

  TransactionModel copyWith({
    double? amount,
    String? walletId,
    String? toWalletId,
    String? category,
    DateTime? date,
    String? notes,
    String? source,
  }) {
    return TransactionModel(
      id: id,
      type: type,
      amount: amount ?? this.amount,
      walletId: walletId ?? this.walletId,
      toWalletId: toWalletId ?? this.toWalletId,
      category: category ?? this.category,
      date: date ?? this.date,
      notes: notes ?? this.notes,
      source: source ?? this.source,
      isFromSms: isFromSms,
      isRecurringInstance: isRecurringInstance,
      createdAt: createdAt,
    );
  }
}
