import 'package:flutter/material.dart';

/// Central place for every enum-like list used across the app.
/// Keeping these here means adding a new category or wallet type
/// is a one-line change, not a hunt through the codebase.
class AppConstants {
  AppConstants._();

  // ---------------------------------------------------------------------
  // Wallet types
  // ---------------------------------------------------------------------
  static const List<Map<String, dynamic>> defaultWallets = [
    {'name': 'Cash', 'icon': 'cash', 'color': 0xFF6EE7B7},
    {'name': 'bKash', 'icon': 'bkash', 'color': 0xFFE2136E},
    {'name': 'Nagad', 'icon': 'nagad', 'color': 0xFFF7941D},
    {'name': 'Rocket', 'icon': 'rocket', 'color': 0xFF8B5CF6},
    {'name': 'Bank Account', 'icon': 'bank', 'color': 0xFF60A5FA},
    {'name': 'Credit Card', 'icon': 'card', 'color': 0xFFF87171},
  ];

  static IconData walletIcon(String key) {
    switch (key) {
      case 'cash':
        return Icons.payments_rounded;
      case 'bkash':
      case 'nagad':
      case 'rocket':
        return Icons.smartphone_rounded;
      case 'bank':
        return Icons.account_balance_rounded;
      case 'card':
        return Icons.credit_card_rounded;
      default:
        return Icons.account_balance_wallet_rounded;
    }
  }

  // ---------------------------------------------------------------------
  // Income categories
  // ---------------------------------------------------------------------
  static const List<String> incomeCategories = [
    'Salary',
    'Business',
    'Freelancing',
    'Gift',
    'Refund',
    'Bonus',
    'Other',
  ];

  // ---------------------------------------------------------------------
  // Expense categories
  // ---------------------------------------------------------------------
  static const List<String> expenseCategories = [
    'Food',
    'Transport',
    'Shopping',
    'Restaurant',
    'Rent',
    'Family',
    'Education',
    'Medicine',
    'Gym',
    'Entertainment',
    'Travel',
    'Mobile Recharge',
    'Internet',
    'Utility Bills',
    'Other',
  ];

  static IconData categoryIcon(String category) {
    switch (category) {
      case 'Salary':
        return Icons.work_rounded;
      case 'Business':
        return Icons.storefront_rounded;
      case 'Freelancing':
        return Icons.laptop_mac_rounded;
      case 'Gift':
        return Icons.card_giftcard_rounded;
      case 'Refund':
        return Icons.replay_circle_filled_rounded;
      case 'Bonus':
        return Icons.stars_rounded;
      case 'Food':
        return Icons.restaurant_rounded;
      case 'Transport':
        return Icons.directions_bus_rounded;
      case 'Shopping':
        return Icons.shopping_bag_rounded;
      case 'Restaurant':
        return Icons.ramen_dining_rounded;
      case 'Rent':
        return Icons.home_rounded;
      case 'Family':
        return Icons.family_restroom_rounded;
      case 'Education':
        return Icons.school_rounded;
      case 'Medicine':
        return Icons.medical_services_rounded;
      case 'Gym':
        return Icons.fitness_center_rounded;
      case 'Entertainment':
        return Icons.movie_rounded;
      case 'Travel':
        return Icons.flight_takeoff_rounded;
      case 'Mobile Recharge':
        return Icons.phone_android_rounded;
      case 'Internet':
        return Icons.wifi_rounded;
      case 'Utility Bills':
        return Icons.bolt_rounded;
      default:
        return Icons.category_rounded;
    }
  }

  // ---------------------------------------------------------------------
  // Bill categories (reuses expense categories where relevant)
  // ---------------------------------------------------------------------
  static const List<String> billCategories = [
    'Internet Bill',
    'Electricity',
    'Rent',
    'Mobile Recharge',
    'EMI',
    'Other',
  ];

  // ---------------------------------------------------------------------
  // Recurrence
  // ---------------------------------------------------------------------
  static const List<String> recurrenceFrequencies = [
    'Daily',
    'Weekly',
    'Monthly',
    'Yearly',
  ];

  // ---------------------------------------------------------------------
  // Currencies supported in Settings
  // ---------------------------------------------------------------------
  static const Map<String, String> currencySymbols = {
    'BDT': '৳',
    'USD': '\$',
    'EUR': '€',
    'GBP': '£',
    'INR': '₹',
  };
}
