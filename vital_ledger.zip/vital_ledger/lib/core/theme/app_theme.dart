import 'package:flutter/material.dart';

/// VITAL // LEDGER — dark HUD aesthetic.
/// Base: near-black graphite background, cyan-mint signal accent for
/// positive/income, warning amber for expense, and a deep violet for
/// highlights (goals/budgets). Numbers get a mono face so amounts feel
/// like readouts, not just labels.
class AppColors {
  AppColors._();

  static const bg = Color(0xFF0B0F14);
  static const surface = Color(0xFF121821);
  static const surfaceRaised = Color(0xFF1A222D);
  static const border = Color(0xFF232D3A);

  static const signal = Color(0xFF4DF0C0); // income / positive
  static const warn = Color(0xFFFF8A5B); // expense / negative
  static const violet = Color(0xFF8B7CF6); // goals / highlights
  static const info = Color(0xFF5BB8FF);

  static const textPrimary = Color(0xFFEAF0F4);
  static const textSecondary = Color(0xFF8C9BAA);
  static const textFaint = Color(0xFF56636F);

  static const danger = Color(0xFFFF5C6C);
}

class AppTheme {
  AppTheme._();

  static const _monoFont = 'JetBrainsMono';
  static const _uiFont = 'Oswald';
  static const _bnFont = 'NotoSansBengali';

  static ThemeData dark() {
    final base = ThemeData.dark(useMaterial3: true);

    return base.copyWith(
      scaffoldBackgroundColor: AppColors.bg,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.signal,
        secondary: AppColors.violet,
        surface: AppColors.surface,
        error: AppColors.danger,
      ),
      fontFamily: _uiFont,
      textTheme: base.textTheme
          .apply(
            fontFamily: _uiFont,
            bodyColor: AppColors.textPrimary,
            displayColor: AppColors.textPrimary,
          )
          .copyWith(
            displaySmall: const TextStyle(
              fontFamily: _monoFont,
              fontWeight: FontWeight.w700,
              fontSize: 32,
              letterSpacing: -0.5,
              color: AppColors.textPrimary,
            ),
            headlineSmall: const TextStyle(
              fontFamily: _uiFont,
              fontWeight: FontWeight.w600,
              fontSize: 20,
              letterSpacing: 0.2,
            ),
            bodySmall: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 12,
            ),
          ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.bg,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          fontFamily: _uiFont,
          fontWeight: FontWeight.w600,
          fontSize: 18,
          letterSpacing: 0.6,
          color: AppColors.textPrimary,
        ),
      ),
      cardTheme: CardThemeData(
        color: AppColors.surface,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: AppColors.border, width: 1),
        ),
      ),
      dividerColor: AppColors.border,
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.surfaceRaised,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.signal, width: 1.4),
        ),
        labelStyle: const TextStyle(color: AppColors.textSecondary),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.signal,
          foregroundColor: Colors.black,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          textStyle: const TextStyle(fontWeight: FontWeight.w600, letterSpacing: 0.4),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.surface,
        selectedItemColor: AppColors.signal,
        unselectedItemColor: AppColors.textFaint,
        type: BottomNavigationBarType.fixed,
        showUnselectedLabels: true,
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.surfaceRaised,
        contentTextStyle: const TextStyle(color: AppColors.textPrimary),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  /// Style for large monetary readouts (Dashboard hero number, etc.)
  static const TextStyle amountLarge = TextStyle(
    fontFamily: _monoFont,
    fontSize: 36,
    fontWeight: FontWeight.w700,
    color: AppColors.textPrimary,
    letterSpacing: -0.5,
  );

  static const TextStyle amountMedium = TextStyle(
    fontFamily: _monoFont,
    fontSize: 20,
    fontWeight: FontWeight.w600,
    color: AppColors.textPrimary,
  );

  static const TextStyle amountSmall = TextStyle(
    fontFamily: _monoFont,
    fontSize: 14,
    fontWeight: FontWeight.w600,
  );

  static const TextStyle bengali = TextStyle(fontFamily: _bnFont, fontSize: 14);
}
