import 'package:intl/intl.dart';

class Formatters {
  Formatters._();

  static String currency(double amount, {String symbol = '৳'}) {
    final formatted = NumberFormat('#,##0.00', 'en_US').format(amount.abs());
    final sign = amount < 0 ? '-' : '';
    return '$sign$symbol$formatted';
  }

  static String currencyCompact(double amount, {String symbol = '৳'}) {
    if (amount.abs() >= 100000) {
      return '$symbol${(amount / 100000).toStringAsFixed(1)}L';
    } else if (amount.abs() >= 1000) {
      return '$symbol${(amount / 1000).toStringAsFixed(1)}k';
    }
    return currency(amount, symbol: symbol);
  }

  static String date(DateTime d) => DateFormat('dd MMM yyyy').format(d);

  static String dateShort(DateTime d) => DateFormat('dd MMM').format(d);

  static String dateTime(DateTime d) => DateFormat('dd MMM, hh:mm a').format(d);

  static String monthYear(DateTime d) => DateFormat('MMMM yyyy').format(d);

  static String relativeDay(DateTime d) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final target = DateTime(d.year, d.month, d.day);
    final diff = today.difference(target).inDays;
    if (diff == 0) return 'Today';
    if (diff == 1) return 'Yesterday';
    if (diff == -1) return 'Tomorrow';
    return dateShort(d);
  }
}
