import 'package:flutter/material.dart';

import '../domain/repositories/planning_repositories.dart';

class SettingsProvider extends ChangeNotifier {
  final SettingsRepository _repo = SettingsRepository();

  String currencyCode = 'BDT';
  String currencySymbol = '৳';
  ThemeMode themeMode = ThemeMode.dark;
  String languageCode = 'en'; // 'en' or 'bn'
  bool dailyReminderEnabled = true;
  bool weeklySummaryEnabled = true;
  bool monthlySummaryEnabled = true;
  bool budgetAlertsEnabled = true;
  bool pinLockEnabled = false;
  bool biometricEnabled = false;
  String? pinHash;

  Future<void> load() async {
    currencyCode = await _repo.get('currencyCode') ?? 'BDT';
    currencySymbol = await _repo.get('currencySymbol') ?? '৳';
    languageCode = await _repo.get('languageCode') ?? 'en';
    themeMode = (await _repo.get('themeMode')) == 'light' ? ThemeMode.light : ThemeMode.dark;
    dailyReminderEnabled = (await _repo.get('dailyReminderEnabled')) != 'false';
    weeklySummaryEnabled = (await _repo.get('weeklySummaryEnabled')) != 'false';
    monthlySummaryEnabled = (await _repo.get('monthlySummaryEnabled')) != 'false';
    budgetAlertsEnabled = (await _repo.get('budgetAlertsEnabled')) != 'false';
    pinLockEnabled = (await _repo.get('pinLockEnabled')) == 'true';
    biometricEnabled = (await _repo.get('biometricEnabled')) == 'true';
    pinHash = await _repo.get('pinHash');
    notifyListeners();
  }

  Future<void> setCurrency(String code, String symbol) async {
    currencyCode = code;
    currencySymbol = symbol;
    await _repo.set('currencyCode', code);
    await _repo.set('currencySymbol', symbol);
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    themeMode = mode;
    await _repo.set('themeMode', mode == ThemeMode.light ? 'light' : 'dark');
    notifyListeners();
  }

  Future<void> setLanguage(String code) async {
    languageCode = code;
    await _repo.set('languageCode', code);
    notifyListeners();
  }

  Future<void> setNotificationToggle(String key, bool value) async {
    await _repo.set(key, value.toString());
    switch (key) {
      case 'dailyReminderEnabled':
        dailyReminderEnabled = value;
        break;
      case 'weeklySummaryEnabled':
        weeklySummaryEnabled = value;
        break;
      case 'monthlySummaryEnabled':
        monthlySummaryEnabled = value;
        break;
      case 'budgetAlertsEnabled':
        budgetAlertsEnabled = value;
        break;
    }
    notifyListeners();
  }

  Future<void> setPin(String pin) async {
    pinHash = _hash(pin);
    pinLockEnabled = true;
    await _repo.set('pinHash', pinHash!);
    await _repo.set('pinLockEnabled', 'true');
    notifyListeners();
  }

  Future<void> disablePinLock() async {
    pinLockEnabled = false;
    await _repo.set('pinLockEnabled', 'false');
    notifyListeners();
  }

  Future<void> setBiometricEnabled(bool value) async {
    biometricEnabled = value;
    await _repo.set('biometricEnabled', value.toString());
    notifyListeners();
  }

  bool verifyPin(String pin) => pinHash == _hash(pin);

  String _hash(String pin) {
    // Lightweight obfuscation, not cryptographic-grade — good enough for a
    // local-only app-open gate. Swap for a proper hash (e.g. crypto package)
    // if this is ever exposed beyond local device storage.
    var hash = 0;
    for (final c in pin.codeUnits) {
      hash = (hash * 31 + c) & 0x7FFFFFFF;
    }
    return hash.toString();
  }
}
