import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../data/models/planning_models.dart';
import '../domain/repositories/planning_repositories.dart';

class GoalProvider extends ChangeNotifier {
  final GoalRepository _repo = GoalRepository();
  final _uuid = const Uuid();

  List<GoalModel> goals = [];

  Future<void> load() async {
    goals = await _repo.getAll();
    notifyListeners();
  }

  Future<void> createGoal({
    required String name,
    required double target,
    double saved = 0,
    String iconKey = 'goal',
    DateTime? deadline,
  }) async {
    await _repo.create(GoalModel(
      id: _uuid.v4(),
      name: name,
      target: target,
      saved: saved,
      iconKey: iconKey,
      deadline: deadline,
      createdAt: DateTime.now(),
    ));
    await load();
  }

  Future<void> addContribution(GoalModel goal, double amount) async {
    final updated = goal.copyWith(saved: goal.saved + amount);
    await _repo.update(updated);
    await load();
  }

  Future<void> deleteGoal(String id) async {
    await _repo.delete(id);
    await load();
  }
}
