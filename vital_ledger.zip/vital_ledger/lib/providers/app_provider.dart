import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../data/models/transaction_model.dart';
import '../data/models/wallet_model.dart';
import '../domain/repositories/transaction_repository.dart';
import '../domain/repositories/wallet_repository.dart';
import '../services/recurring_service.dart';

/// Holds wallets + the full transaction ledger in memory (source of truth
/// stays in SQLite; this is a cache that every screen reads from so the
/// UI updates instantly without a DB round trip on every rebuild).
class AppProvider extends ChangeNotifier {
  final WalletRepository _walletRepo = WalletRepository();
  final TransactionRepository _txRepo = TransactionRepository();
  final _uuid = const Uuid();

  List<WalletModel> wallets = [];
  List<TransactionModel> transactions = [];
  bool isLoading = true;

  Future<void> init() async {
    await _walletRepo.seedDefaultsIfEmpty();
    await reload();
    // Materialize any due recurring transactions (salary, rent, etc.)
    // before computing dashboard numbers, so today's view is accurate.
    await RecurringService().runDueRecurring(onTransactionCreated: addTransaction);
    isLoading = false;
    notifyListeners();
  }

  Future<void> reload() async {
    wallets = await _walletRepo.getAll();
    transactions = await _txRepo.getAll();
    notifyListeners();
  }

  // ---------------------------------------------------------------------
  // Wallet CRUD
  // ---------------------------------------------------------------------
  Future<void> createWallet(WalletModel wallet) async {
    await _walletRepo.create(wallet);
    await reload();
  }

  Future<void> deleteWallet(String id) async {
    await _walletRepo.delete(id);
    await reload();
  }

  WalletModel? walletById(String id) {
    try {
      return wallets.firstWhere((w) => w.id == id);
    } catch (_) {
      return null;
    }
  }

  WalletSummary summaryFor(WalletModel wallet) {
    double received = wallet.openingBalance > 0 ? 0 : 0;
    double sent = 0;
    for (final tx in transactions) {
      if (tx.type == TxType.income && tx.walletId == wallet.id) {
        received += tx.amount;
      } else if (tx.type == TxType.expense && tx.walletId == wallet.id) {
        sent += tx.amount;
      } else if (tx.type == TxType.transfer) {
        if (tx.walletId == wallet.id) sent += tx.amount;
        if (tx.toWalletId == wallet.id) received += tx.amount;
      }
    }
    return WalletSummary(wallet: wallet, totalReceived: received, totalSent: sent);
  }

  List<TransactionModel> transactionsFor(String walletId) {
    return transactions.where((t) => t.walletId == walletId || t.toWalletId == walletId).toList()
      ..sort((a, b) => b.date.compareTo(a.date));
  }

  // ---------------------------------------------------------------------
  // Transaction CRUD
  // ---------------------------------------------------------------------
  Future<TransactionModel> addTransaction({
    required TxType type,
    required double amount,
    required String walletId,
    String? toWalletId,
    required String category,
    required DateTime date,
    String notes = '',
    String source = '',
    bool isFromSms = false,
  }) async {
    final tx = TransactionModel(
      id: _uuid.v4(),
      type: type,
      amount: amount,
      walletId: walletId,
      toWalletId: toWalletId,
      category: category,
      date: date,
      notes: notes,
      source: source,
      isFromSms: isFromSms,
      createdAt: DateTime.now(),
    );
    await _txRepo.create(tx);
    await reload();
    return tx;
  }

  Future<void> updateTransaction(TransactionModel tx) async {
    await _txRepo.update(tx);
    await reload();
  }

  Future<void> deleteTransaction(String id) async {
    await _txRepo.delete(id);
    await reload();
  }

  // ---------------------------------------------------------------------
  // Dashboard aggregates
  // ---------------------------------------------------------------------
  double get totalMoney {
    double total = 0;
    for (final w in wallets) {
      total += summaryFor(w).balance;
    }
    return total;
  }

  double balanceForWalletNamed(String name) {
    final w = wallets.where((x) => x.name.toLowerCase() == name.toLowerCase());
    if (w.isEmpty) return 0;
    return summaryFor(w.first).balance;
  }

  bool get isCurrentMonth => true;

  List<TransactionModel> _thisMonth() {
    final now = DateTime.now();
    return transactions.where((t) => t.date.year == now.year && t.date.month == now.month).toList();
  }

  double get incomeThisMonth => _thisMonth()
      .where((t) => t.type == TxType.income)
      .fold(0.0, (sum, t) => sum + t.amount);

  double get expenseThisMonth => _thisMonth()
      .where((t) => t.type == TxType.expense)
      .fold(0.0, (sum, t) => sum + t.amount);

  double get savingsThisMonth => incomeThisMonth - expenseThisMonth;

  List<TransactionModel> get recentTransactions {
    final sorted = [...transactions]..sort((a, b) => b.date.compareTo(a.date));
    return sorted.take(8).toList();
  }

  /// Category → total spent this month, sorted descending.
  Map<String, double> expenseByCategoryThisMonth() {
    final map = <String, double>{};
    for (final t in _thisMonth().where((t) => t.type == TxType.expense)) {
      map[t.category] = (map[t.category] ?? 0) + t.amount;
    }
    final entries = map.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return {for (final e in entries) e.key: e.value};
  }

  /// Last N months of income vs expense, for the statistics screen.
  List<MonthlyTotals> monthlyTotals(int months) {
    final now = DateTime.now();
    final result = <MonthlyTotals>[];
    for (int i = months - 1; i >= 0; i--) {
      final target = DateTime(now.year, now.month - i, 1);
      final monthTx = transactions.where((t) => t.date.year == target.year && t.date.month == target.month);
      final income = monthTx.where((t) => t.type == TxType.income).fold(0.0, (s, t) => s + t.amount);
      final expense = monthTx.where((t) => t.type == TxType.expense).fold(0.0, (s, t) => s + t.amount);
      result.add(MonthlyTotals(month: target, income: income, expense: expense));
    }
    return result;
  }

  // ---------------------------------------------------------------------
  // Analytics
  // ---------------------------------------------------------------------
  TransactionModel? get biggestExpense {
    final expenses = transactions.where((t) => t.type == TxType.expense).toList();
    if (expenses.isEmpty) return null;
    expenses.sort((a, b) => b.amount.compareTo(a.amount));
    return expenses.first;
  }

  TransactionModel? get highestIncome {
    final incomes = transactions.where((t) => t.type == TxType.income).toList();
    if (incomes.isEmpty) return null;
    incomes.sort((a, b) => b.amount.compareTo(a.amount));
    return incomes.first;
  }

  double get dailyAverageSpending {
    final expenses = _thisMonth().where((t) => t.type == TxType.expense);
    if (expenses.isEmpty) return 0;
    final total = expenses.fold(0.0, (s, t) => s + t.amount);
    return total / DateTime.now().day;
  }

  double get monthlyAverageSpending {
    final totals = monthlyTotals(6).where((m) => m.expense > 0);
    if (totals.isEmpty) return 0;
    return totals.fold(0.0, (s, m) => s + m.expense) / totals.length;
  }

  double get savingsRate {
    final income = incomeThisMonth;
    if (income <= 0) return 0;
    return (savingsThisMonth / income).clamp(-1, 1) * 100;
  }

  double get netCashFlow => incomeThisMonth - expenseThisMonth;
}

class MonthlyTotals {
  final DateTime month;
  final double income;
  final double expense;
  MonthlyTotals({required this.month, required this.income, required this.expense});
}
