import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../data/models/planning_models.dart';
import '../data/models/transaction_model.dart';
import '../domain/repositories/planning_repositories.dart';
import '../services/notification_service.dart';
import 'app_provider.dart';

class BudgetProvider extends ChangeNotifier {
  final BudgetRepository _repo = BudgetRepository();
  final _uuid = const Uuid();
  final AppProvider appProvider;

  BudgetProvider(this.appProvider);

  List<BudgetModel> budgets = [];
  String get currentMonthKey => DateFormat('yyyy-MM').format(DateTime.now());

  Future<void> load() async {
    budgets = await _repo.getForMonth(currentMonthKey);
    notifyListeners();
  }

  Future<void> setBudget(String category, double limit) async {
    final existing = budgets.where((b) => b.category == category);
    final model = BudgetModel(
      id: existing.isNotEmpty ? existing.first.id : _uuid.v4(),
      category: category,
      limit: limit,
      monthKey: currentMonthKey,
    );
    await _repo.upsert(model);
    await load();
  }

  Future<void> deleteBudget(String id) async {
    await _repo.delete(id);
    await load();
  }

  double spentOn(String category) {
    final now = DateTime.now();
    return appProvider.transactions
        .where((t) =>
            t.type == TxType.expense &&
            t.category == category &&
            t.date.year == now.year &&
            t.date.month == now.month)
        .fold(0.0, (s, t) => s + t.amount);
  }

  double progressOn(BudgetModel b) => b.limit <= 0 ? 0 : (spentOn(b.category) / b.limit).clamp(0, 2);

  /// Called after any expense is added — checks every budget and fires a
  /// local notification once when a category crosses 80% or 100% for the
  /// first time this month (tracked via notified80/notified100 flags so
  /// the user isn't spammed on every subsequent transaction).
  Future<void> checkThresholds() async {
    for (final b in budgets) {
      final ratio = progressOn(b);
      if (ratio >= 1.0 && !b.notified100) {
        await NotificationService().show(
          title: 'Budget exceeded: ${b.category}',
          body: 'You have spent 100% or more of your ${b.category} budget this month.',
        );
        await _repo.upsert(b.copyWith(notified100: true, notified80: true));
      } else if (ratio >= 0.8 && !b.notified80) {
        await NotificationService().show(
          title: 'Budget warning: ${b.category}',
          body: 'You have used 80% of your ${b.category} budget this month.',
        );
        await _repo.upsert(b.copyWith(notified80: true));
      }
    }
    await load();
  }
}
