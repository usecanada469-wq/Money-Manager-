import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../data/models/planning_models.dart';
import '../domain/repositories/planning_repositories.dart';
import '../services/notification_service.dart';

class BillProvider extends ChangeNotifier {
  final BillRepository _repo = BillRepository();
  final _uuid = const Uuid();

  List<BillModel> bills = [];

  Future<void> load() async {
    bills = await _repo.getAll();
    notifyListeners();
  }

  Future<void> createBill({
    required String name,
    required double amount,
    required DateTime dueDate,
    required String category,
    bool isRecurring = false,
    String recurrenceFrequency = '',
  }) async {
    final bill = BillModel(
      id: _uuid.v4(),
      name: name,
      amount: amount,
      dueDate: dueDate,
      category: category,
      isRecurring: isRecurring,
      recurrenceFrequency: recurrenceFrequency,
    );
    await _repo.create(bill);
    await NotificationService().scheduleBillReminder(bill);
    await load();
  }

  Future<void> markPaid(BillModel bill) async {
    var updated = bill.copyWith(isPaid: true);
    await _repo.update(updated);
    if (bill.isRecurring) {
      final nextDue = RecurringModel.advance(bill.dueDate, bill.recurrenceFrequency);
      final nextBill = BillModel(
        id: _uuid.v4(),
        name: bill.name,
        amount: bill.amount,
        dueDate: nextDue,
        category: bill.category,
        isRecurring: true,
        recurrenceFrequency: bill.recurrenceFrequency,
      );
      await _repo.create(nextBill);
      await NotificationService().scheduleBillReminder(nextBill);
    }
    await load();
  }

  Future<void> deleteBill(String id) async {
    await _repo.delete(id);
    await load();
  }

  List<BillModel> get upcoming =>
      bills.where((b) => !b.isPaid).toList()..sort((a, b) => a.dueDate.compareTo(b.dueDate));
}
