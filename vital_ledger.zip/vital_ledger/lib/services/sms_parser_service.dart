/// Result of attempting to parse a finance SMS. If [isConfident] is false,
/// the UI must show a confirmation dialog pre-filled with whatever was
/// extracted rather than silently saving — this matches the spec's
/// "if parsing fails, ask the user to confirm" requirement.
class ParsedSmsTransaction {
  final double? amount;
  final String? sender;
  final String? receiver;
  final DateTime? date;
  final String action; // 'Cash Out' | 'Cash In' | 'Send Money' | 'Payment' | 'Add Money' | 'Unknown'
  final String provider; // 'bKash' | 'Nagad' | 'Rocket' | 'Bank'
  final bool isConfident;
  final String rawBody;

  ParsedSmsTransaction({
    this.amount,
    this.sender,
    this.receiver,
    this.date,
    required this.action,
    required this.provider,
    required this.isConfident,
    required this.rawBody,
  });

  bool get isIncome => action == 'Cash In' || action == 'Add Money' || action == 'Received';
  bool get isExpense =>
      action == 'Cash Out' || action == 'Send Money' || action == 'Payment';
}

/// Parses raw SMS bodies from mobile financial services and banks common
/// in Bangladesh. These regex patterns are based on the publicly known
/// message formats for bKash, Nagad, and Rocket as of early 2026; SMS
/// formats change without notice, so `parse()` always falls back to
/// `isConfident = false` rather than guessing when a pattern doesn't match
/// cleanly — the caller must then prompt the user to confirm/edit before
/// saving anything to the ledger.
class SmsParserService {
  static const _providerSenders = {
    'bKash': ['bKash', '16247'],
    'Nagad': ['Nagad', '16167'],
    'Rocket': ['Rocket', 'DBBL Rocket', '16216'],
  };

  ParsedSmsTransaction parse(String sender, String body) {
    final provider = _detectProvider(sender, body);
    if (provider == 'bKash') return _parseBkash(body);
    if (provider == 'Nagad') return _parseNagad(body);
    if (provider == 'Rocket') return _parseRocket(body);
    return _parseGenericBank(body);
  }

  String _detectProvider(String sender, String body) {
    final lowerBody = body.toLowerCase();
    for (final entry in _providerSenders.entries) {
      for (final id in entry.value) {
        if (sender.toLowerCase().contains(id.toLowerCase()) ||
            lowerBody.contains(entry.key.toLowerCase())) {
          return entry.key;
        }
      }
    }
    return 'Bank';
  }

  double? _extractAmount(String body) {
    // Matches "Tk 1,250.00", "Tk. 500", "BDT 2000.5"
    final match = RegExp(r'(?:Tk\.?|BDT)\s*([\d,]+(?:\.\d{1,2})?)', caseSensitive: false).firstMatch(body);
    if (match == null) return null;
    return double.tryParse(match.group(1)!.replaceAll(',', ''));
  }

  String? _extractCounterparty(String body, List<String> keywords) {
    for (final kw in keywords) {
      final match = RegExp('$kw\\s*(?:to|from)?\\s*([0-9A-Za-z+]{6,15})', caseSensitive: false)
          .firstMatch(body);
      if (match != null) return match.group(1);
    }
    return null;
  }

  DateTime? _extractDate(String body) {
    // Matches "at 14:32 on 04/08/2026" or "04/08/2026 14:32"
    final match = RegExp(r'(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})(?:\D+(\d{1,2}):(\d{2}))?').firstMatch(body);
    if (match == null) return null;
    try {
      final day = int.parse(match.group(1)!);
      final month = int.parse(match.group(2)!);
      var year = int.parse(match.group(3)!);
      if (year < 100) year += 2000;
      final hour = match.group(4) != null ? int.parse(match.group(4)!) : 0;
      final minute = match.group(5) != null ? int.parse(match.group(5)!) : 0;
      return DateTime(year, month, day, hour, minute);
    } catch (_) {
      return null;
    }
  }

  String _detectAction(String body) {
    final b = body.toLowerCase();
    if (b.contains('cash out')) return 'Cash Out';
    if (b.contains('cash in')) return 'Cash In';
    if (b.contains('send money')) return 'Send Money';
    if (b.contains('payment')) return 'Payment';
    if (b.contains('add money')) return 'Add Money';
    if (b.contains('received')) return 'Received';
    return 'Unknown';
  }

  ParsedSmsTransaction _parseBkash(String body) {
    final amount = _extractAmount(body);
    final action = _detectAction(body);
    final counterparty = _extractCounterparty(body, ['to', 'from']);
    final date = _extractDate(body);
    final confident = amount != null && action != 'Unknown';
    return ParsedSmsTransaction(
      amount: amount,
      sender: action == 'Cash In' || action == 'Received' ? counterparty : null,
      receiver: action == 'Cash Out' || action == 'Send Money' || action == 'Payment' ? counterparty : null,
      date: date,
      action: action,
      provider: 'bKash',
      isConfident: confident,
      rawBody: body,
    );
  }

  ParsedSmsTransaction _parseNagad(String body) {
    final amount = _extractAmount(body);
    final action = _detectAction(body);
    final counterparty = _extractCounterparty(body, ['to', 'from']);
    final date = _extractDate(body);
    final confident = amount != null && action != 'Unknown';
    return ParsedSmsTransaction(
      amount: amount,
      sender: action == 'Cash In' ? counterparty : null,
      receiver: action == 'Cash Out' || action == 'Send Money' ? counterparty : null,
      date: date,
      action: action,
      provider: 'Nagad',
      isConfident: confident,
      rawBody: body,
    );
  }

  ParsedSmsTransaction _parseRocket(String body) {
    final amount = _extractAmount(body);
    final action = _detectAction(body);
    final counterparty = _extractCounterparty(body, ['to', 'from']);
    final date = _extractDate(body);
    final confident = amount != null && action != 'Unknown';
    return ParsedSmsTransaction(
      amount: amount,
      sender: action == 'Cash In' ? counterparty : null,
      receiver: action == 'Cash Out' || action == 'Send Money' ? counterparty : null,
      date: date,
      action: action,
      provider: 'Rocket',
      isConfident: confident,
      rawBody: body,
    );
  }

  ParsedSmsTransaction _parseGenericBank(String body) {
    final amount = _extractAmount(body);
    final b = body.toLowerCase();
    String action = 'Unknown';
    if (b.contains('debited') || b.contains('withdrawn')) action = 'Payment';
    if (b.contains('credited') || b.contains('deposited')) action = 'Received';
    final date = _extractDate(body);
    // Bank SMS formats vary far more than MFS formats, so confidence is
    // intentionally conservative — this almost always routes to the
    // confirm-before-save dialog.
    final confident = amount != null && action != 'Unknown' && date != null;
    return ParsedSmsTransaction(
      amount: amount,
      sender: null,
      receiver: null,
      date: date,
      action: action,
      provider: 'Bank',
      isConfident: confident,
      rawBody: body,
    );
  }
}
