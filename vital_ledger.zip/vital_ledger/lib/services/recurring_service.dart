import '../data/models/planning_models.dart';
import '../data/models/transaction_model.dart';
import '../domain/repositories/planning_repositories.dart';

/// Checks every active recurring template on app start and, for any whose
/// `nextRunDate` has passed, creates the corresponding transaction(s) and
/// rolls the template forward. This is the mechanism behind "Salary, Rent,
/// Subscriptions, Internet Bill" auto-repeating as specified.
///
/// Design note: this runs opportunistically on app launch rather than via
/// a background isolate/WorkManager job, because Flutter has no reliable
/// cross-platform way to guarantee background execution without native
/// platform channels. For a user who opens the app at least a few times a
/// week (the common case for a finance tracker) this produces the same
/// result; a background job could be added later using `workmanager` if
/// true background execution is required.
class RecurringService {
  final RecurringRepository _repo = RecurringRepository();

  Future<void> runDueRecurring({
    required Future<TransactionModel> Function({
      required TxType type,
      required double amount,
      required String walletId,
      String? toWalletId,
      required String category,
      required DateTime date,
      String notes,
      String source,
      bool isFromSms,
    }) onTransactionCreated,
  }) async {
    final all = await _repo.getAll();
    final now = DateTime.now();

    for (final r in all) {
      if (!r.isActive) continue;
      var next = r.nextRunDate;
      var guard = 0; // safety valve in case of a malformed frequency loop
      while (!next.isAfter(now) && guard < 500) {
        await onTransactionCreated(
          type: r.type == 'income' ? TxType.income : TxType.expense,
          amount: r.amount,
          walletId: r.walletId,
          category: r.category,
          date: next,
          notes: r.notes.isEmpty ? 'Recurring: ${r.category}' : r.notes,
        );
        next = RecurringModel.advance(next, r.frequency);
        guard++;
      }
      if (next != r.nextRunDate) {
        await _repo.update(r.copyWith(nextRunDate: next));
      }
    }
  }

  Future<void> createTemplate(RecurringModel model) => _repo.create(model);
  Future<void> deleteTemplate(String id) => _repo.delete(id);
  Future<List<RecurringModel>> getAll() => _repo.getAll();
  Future<void> setActive(RecurringModel model, bool active) => _repo.update(model.copyWith(isActive: active));
}
