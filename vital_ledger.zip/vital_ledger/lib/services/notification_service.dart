import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest_all.dart' as tzdata;

import '../data/models/planning_models.dart';

/// Thin wrapper around flutter_local_notifications. All scheduling is
/// device-local — no push server, no account, matching the app's
/// offline-first / no-login requirement.
class NotificationService {
  NotificationService._internal();
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;

  final _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    tzdata.initializeTimeZones();
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings();
    await _plugin.initialize(
      const InitializationSettings(android: androidInit, iOS: iosInit),
    );
    _initialized = true;
  }

  Future<void> show({required String title, required String body}) async {
    await init();
    await _plugin.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'vital_ledger_alerts',
          'VITAL Ledger Alerts',
          channelDescription: 'Budget and account alerts',
          importance: Importance.high,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(),
      ),
    );
  }

  /// Daily "did you record today's expenses?" nudge.
  Future<void> scheduleDailyReminder({int hour = 21, int minute = 0}) async {
    await init();
    await _plugin.zonedSchedule(
      1001,
      'VITAL // LEDGER',
      "Did you record today's expenses?",
      _nextInstanceOfTime(hour, minute),
      const NotificationDetails(
        android: AndroidNotificationDetails('daily_reminder', 'Daily Reminder'),
        iOS: DarwinNotificationDetails(),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  Future<void> scheduleWeeklySummary() async {
    await init();
    await _plugin.zonedSchedule(
      1002,
      'Weekly Summary',
      'Your weekly income/expense summary is ready. Check the Statistics tab.',
      _nextInstanceOfWeekday(DateTime.sunday, 20, 0),
      const NotificationDetails(
        android: AndroidNotificationDetails('weekly_summary', 'Weekly Summary'),
        iOS: DarwinNotificationDetails(),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
    );
  }

  Future<void> scheduleMonthlySummary() async {
    await init();
    final now = DateTime.now();
    final firstOfNextMonth = DateTime(now.year, now.month + 1, 1, 20, 0);
    await _plugin.zonedSchedule(
      1003,
      'Monthly Summary',
      'Your monthly summary is ready — see how this month compared to last.',
      tz.TZDateTime.from(firstOfNextMonth, tz.local),
      const NotificationDetails(
        android: AndroidNotificationDetails('monthly_summary', 'Monthly Summary'),
        iOS: DarwinNotificationDetails(),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
    );
  }

  Future<void> scheduleBillReminder(BillModel bill, {int daysBefore = 2}) async {
    await init();
    final reminderDate = bill.dueDate.subtract(Duration(days: daysBefore));
    if (reminderDate.isBefore(DateTime.now())) return;
    await _plugin.zonedSchedule(
      bill.id.hashCode & 0x7FFFFFFF,
      'Upcoming bill: ${bill.name}',
      'Due ${bill.dueDate.day}/${bill.dueDate.month} — amount ${bill.amount.toStringAsFixed(0)}',
      tz.TZDateTime.from(reminderDate, tz.local),
      const NotificationDetails(
        android: AndroidNotificationDetails('bill_reminder', 'Bill Reminders'),
        iOS: DarwinNotificationDetails(),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
    );
  }

  Future<void> cancelAll() async {
    await init();
    await _plugin.cancelAll();
  }

  tz.TZDateTime _nextInstanceOfTime(int hour, int minute) {
    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    if (scheduled.isBefore(now)) scheduled = scheduled.add(const Duration(days: 1));
    return scheduled;
  }

  tz.TZDateTime _nextInstanceOfWeekday(int weekday, int hour, int minute) {
    var scheduled = _nextInstanceOfTime(hour, minute);
    while (scheduled.weekday != weekday) {
      scheduled = scheduled.add(const Duration(days: 1));
    }
    return scheduled;
  }
}
