import 'package:local_auth/local_auth.dart';

/// Wraps device fingerprint/Face unlock. This defers entirely to the
/// OS-level biometric prompt (Android BiometricPrompt / iOS Face ID
/// dialog) — the app never sees or stores the actual biometric data,
/// only a yes/no "authenticated" result.
class AuthService {
  final LocalAuthentication _auth = LocalAuthentication();

  Future<bool> isBiometricAvailable() async {
    try {
      final canCheck = await _auth.canCheckBiometrics;
      final isSupported = await _auth.isDeviceSupported();
      return canCheck && isSupported;
    } catch (_) {
      return false;
    }
  }

  Future<bool> authenticate({String reason = 'Unlock VITAL // LEDGER'}) async {
    try {
      return await _auth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(
          biometricOnly: false, // allows device PIN/pattern as fallback
          stickyAuth: true,
        ),
      );
    } catch (_) {
      return false;
    }
  }
}
