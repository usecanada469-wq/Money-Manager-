import 'dart:io';

import 'package:csv/csv.dart';
import 'package:excel/excel.dart' as xls;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';

import '../core/utils/formatters.dart';
import '../data/models/transaction_model.dart';
import '../data/models/wallet_model.dart';

/// Generates export files into the app's temp directory and hands them
/// to the OS share sheet — the user picks where the file actually goes
/// (Drive, WhatsApp, Files app, etc.), which is the standard, permission-
/// safe way to "export" from a sandboxed Android/iOS app.
class ExportService {
  Future<File> _writeToTemp(String filename, List<int> bytes) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$filename');
    await file.writeAsBytes(bytes);
    return file;
  }

  String _walletName(List<WalletModel> wallets, String id) {
    final match = wallets.where((w) => w.id == id);
    return match.isEmpty ? 'Unknown' : match.first.name;
  }

  Future<void> exportCsv(List<TransactionModel> txs, List<WalletModel> wallets) async {
    final rows = <List<String>>[
      ['Date', 'Type', 'Category', 'Wallet', 'Amount', 'Source', 'Notes'],
      for (final t in txs)
        [
          Formatters.date(t.date),
          t.type.name,
          t.category,
          _walletName(wallets, t.walletId),
          t.amount.toStringAsFixed(2),
          t.source,
          t.notes,
        ],
    ];
    final csvString = const ListToCsvConverter().convert(rows);
    final file = await _writeToTemp(
      'vital_ledger_export_${DateTime.now().millisecondsSinceEpoch}.csv',
      csvString.codeUnits,
    );
    await Share.shareXFiles([XFile(file.path)], text: 'VITAL // LEDGER export (CSV)');
  }

  Future<void> exportExcel(List<TransactionModel> txs, List<WalletModel> wallets) async {
    final workbook = xls.Excel.createExcel();
    final sheet = workbook['Transactions'];
    sheet.appendRow(['Date', 'Type', 'Category', 'Wallet', 'Amount', 'Source', 'Notes']
        .map((e) => xls.TextCellValue(e))
        .toList());
    for (final t in txs) {
      sheet.appendRow([
        xls.TextCellValue(Formatters.date(t.date)),
        xls.TextCellValue(t.type.name),
        xls.TextCellValue(t.category),
        xls.TextCellValue(_walletName(wallets, t.walletId)),
        xls.DoubleCellValue(t.amount),
        xls.TextCellValue(t.source),
        xls.TextCellValue(t.notes),
      ]);
    }
    final bytes = workbook.encode();
    if (bytes == null) return;
    final file = await _writeToTemp(
      'vital_ledger_export_${DateTime.now().millisecondsSinceEpoch}.xlsx',
      bytes,
    );
    await Share.shareXFiles([XFile(file.path)], text: 'VITAL // LEDGER export (Excel)');
  }

  Future<void> exportPdf(List<TransactionModel> txs, List<WalletModel> wallets) async {
    final doc = pw.Document();
    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        header: (context) => pw.Text(
          'VITAL // LEDGER — Transaction Export',
          style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold),
        ),
        build: (context) => [
          pw.SizedBox(height: 12),
          pw.Table.fromTextArray(
            headers: ['Date', 'Type', 'Category', 'Wallet', 'Amount', 'Notes'],
            data: txs
                .map((t) => [
                      Formatters.date(t.date),
                      t.type.name,
                      t.category,
                      _walletName(wallets, t.walletId),
                      t.amount.toStringAsFixed(2),
                      t.notes,
                    ])
                .toList(),
            cellStyle: const pw.TextStyle(fontSize: 9),
            headerStyle: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold),
            cellAlignment: pw.Alignment.centerLeft,
          ),
        ],
      ),
    );
    final bytes = await doc.save();
    final file = await _writeToTemp(
      'vital_ledger_export_${DateTime.now().millisecondsSinceEpoch}.pdf',
      bytes,
    );
    await Share.shareXFiles([XFile(file.path)], text: 'VITAL // LEDGER export (PDF)');
  }
}
