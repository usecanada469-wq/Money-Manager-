import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../data/db/database_helper.dart';

/// Full local backup/restore as a single JSON file — no cloud account
/// involved. "Export Backup" writes the file and opens the share sheet
/// (so the user can save it to Drive, email it to themselves, etc.);
/// "Import Backup" lets the user pick a previously exported file and
/// restores every table from it. This is intentionally simple (whole-
/// database snapshot) rather than incremental sync, which keeps the
/// data model easy to extend with real cloud sync later — the same
/// JSON shape can just be POSTed to a server instead of written to disk.
class BackupService {
  final _db = DatabaseHelper.instance;

  static const _tables = ['wallets', 'transactions', 'budgets', 'goals', 'bills', 'recurring', 'settings'];

  Future<File> exportBackup() async {
    final db = await _db.database;
    final data = <String, dynamic>{
      'exportedAt': DateTime.now().toIso8601String(),
      'schemaVersion': DatabaseHelper.schemaVersion,
    };
    for (final table in _tables) {
      data[table] = await db.query(table);
    }
    final jsonString = const JsonEncoder.withIndent('  ').convert(data);
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/vital_ledger_backup_${DateTime.now().millisecondsSinceEpoch}.json');
    await file.writeAsString(jsonString);
    return file;
  }

  Future<void> exportAndShareBackup() async {
    final file = await exportBackup();
    await Share.shareXFiles([XFile(file.path)], text: 'VITAL // LEDGER backup');
  }

  /// Returns true if a backup file was picked and successfully restored.
  Future<bool> importBackup() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json']);
    if (result == null || result.files.single.path == null) return false;

    final file = File(result.files.single.path!);
    final content = await file.readAsString();
    final data = jsonDecode(content) as Map<String, dynamic>;

    final db = await _db.database;
    await db.transaction((txn) async {
      for (final table in _tables) {
        if (data[table] == null) continue;
        await txn.delete(table);
        for (final row in (data[table] as List)) {
          await txn.insert(table, Map<String, dynamic>.from(row as Map));
        }
      }
    });
    return true;
  }

  Future<void> wipeLocalData() => _db.wipeAllData();
}
