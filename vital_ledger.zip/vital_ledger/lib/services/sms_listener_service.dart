import 'package:permission_handler/permission_handler.dart';
import 'package:telephony/telephony.dart';

import 'sms_parser_service.dart';

/// Wires up real-time SMS listening on Android.
///
/// IMPORTANT — platform limitation, not a bug:
/// - iOS does not allow any app to read SMS content. This feature is
///   Android-only by OS design; on iOS `requestPermission()` will return
///   false immediately and this service becomes a no-op.
/// - Even on Android, this requires the READ_SMS and RECEIVE_SMS
///   permissions declared in AndroidManifest.xml (see the manifest
///   snippet in README.md) and the user granting them at runtime.
/// - This can only be exercised on a real device or emulator with SMS
///   capability — it cannot be verified from source review alone.
class SmsListenerService {
  final Telephony _telephony = Telephony.instance;
  final SmsParserService _parser = SmsParserService();

  Future<bool> requestPermission() async {
    final status = await Permission.sms.request();
    return status.isGranted;
  }

  /// [onParsed] is called for every incoming SMS from a recognized
  /// financial sender. The caller (see AddTransactionScreen /
  /// DashboardScreen) decides whether to auto-save (when
  /// `parsed.isConfident` is true) or show a confirmation sheet first.
  Future<void> startListening({
    required void Function(ParsedSmsTransaction parsed) onParsed,
  }) async {
    final granted = await requestPermission();
    if (!granted) return;

    _telephony.listenIncomingSms(
      onNewMessage: (SmsMessage message) {
        final body = message.body ?? '';
        final sender = message.address ?? '';
        if (!_looksFinancial(body)) return;
        final parsed = _parser.parse(sender, body);
        onParsed(parsed);
      },
      listenInBackground: false,
    );
  }

  /// Scans existing inbox messages once (e.g. on first setup) so
  /// transactions sent before the app was installed can still be
  /// reviewed and imported.
  Future<List<ParsedSmsTransaction>> scanInbox({int limit = 50}) async {
    final granted = await requestPermission();
    if (!granted) return [];
    final messages = await _telephony.getInboxSms(
      columns: [SmsColumn.ADDRESS, SmsColumn.BODY, SmsColumn.DATE],
      sortOrder: [OrderBy(SmsColumn.DATE, sort: Sort.DESC)],
    );
    final financial = messages.where((m) => _looksFinancial(m.body ?? '')).take(limit);
    return financial
        .map((m) => _parser.parse(m.address ?? '', m.body ?? ''))
        .toList();
  }

  bool _looksFinancial(String body) {
    final b = body.toLowerCase();
    const keywords = [
      'bkash',
      'nagad',
      'rocket',
      'cash out',
      'cash in',
      'send money',
      'payment',
      'add money',
      'debited',
      'credited',
      'tk ',
      'bdt',
    ];
    return keywords.any(b.contains);
  }
}
